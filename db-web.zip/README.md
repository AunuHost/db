# Loudness DB

Hosted document database platform with:

- Discord-only login
- user dashboard
- admin dashboard
- per-database API keys
- built-in file manager
- status page
- docs page
- Discord bot commands

## Stack

- Next.js 14
- TypeScript
- Prisma
- SQLite for development
- Discord.js

## Running the project

1. Copy `.env.example` to `.env`
2. Fill in `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`, `DISCORD_BOT_TOKEN`, and `DISCORD_OWNER_ID`
3. Run:

```bash
npm install
npx prisma db push
npm run db:seed
npm run dev
```

The web app runs on:

- bind host: `0.0.0.0`
- port: `8999`
- public URL: `https://db.loudness.biz.id`

## Running the bot

```bash
npm run bot
```

## Architecture notes

This project builds a hosted logical document database with UX inspired by modern cloud database products. It is not a wire-compatible MongoDB server, but it provides:

- collection/document CRUD
- file manager CRUD
- API key auth
- monitoring snapshot
- admin control plane
- Discord automation layer

## Primary public endpoints

- `GET /api/v1/db/:databaseId/collections/:collectionName`
- `POST /api/v1/db/:databaseId/collections/:collectionName`
- `PUT /api/v1/db/:databaseId/collections/:collectionName`
- `DELETE /api/v1/db/:databaseId/collections/:collectionName?documentId=...`
- `GET /api/v1/db/:databaseId/collections`
- `GET /api/v1/db/:databaseId/stats`
- `GET /api/v1/db/:databaseId/health`
- `POST /api/v1/db/:databaseId/search`
- `GET /api/v1/db/:databaseId/export`
- `GET /api/v1/files/:databaseId`
- `POST /api/v1/files/:databaseId`
- `DELETE /api/v1/files/:databaseId?path=/config.json`
- `GET /api/v1/system/health`

Use the header:

```bash
x-api-key: ldb_xxxxxxxxx
```

## Extra security features

- public API anti-flood protection based on IP and plan
- cooldowns for deploy, restart, stop, start, suspend, and redeploy
- payload limits for files and documents
- quota enforcement during writes
- path traversal protection
- maintenance gate and blocking for suspended or stopped databases
- security headers on both web and API
