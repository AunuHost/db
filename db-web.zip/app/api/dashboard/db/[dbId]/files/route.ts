import { NextRequest, NextResponse } from "next/server";
import { deleteFileEntry, upsertFileEntry } from "@/lib/db-service";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";

export async function POST(request: NextRequest, { params }: { params: { dbId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ message: "Unauthorized." }, { status: 401 });
    }
    const body = await request.json();
    const database = await prisma.dbInstance.findUniqueOrThrow({ where: { id: params.dbId } });

    if (database.ownerId !== user.id) {
      return NextResponse.json({ message: "Forbidden." }, { status: 403 });
    }

    await upsertFileEntry(params.dbId, user.id, body);
    return NextResponse.json({ message: "File saved." });
  } catch (error) {
    return NextResponse.json(
      {
        message: error instanceof Error ? error.message : "Failed to save file."
      },
      { status: 400 }
    );
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { dbId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ message: "Unauthorized." }, { status: 401 });
    }
    const path = request.nextUrl.searchParams.get("path");
    const database = await prisma.dbInstance.findUniqueOrThrow({ where: { id: params.dbId } });

    if (database.ownerId !== user.id || !path) {
      return NextResponse.json({ message: "Forbidden." }, { status: 403 });
    }

    await deleteFileEntry(params.dbId, path);
    return NextResponse.json({ message: "File deleted." });
  } catch {
    return NextResponse.json({ message: "Failed to delete file." }, { status: 400 });
  }
}
