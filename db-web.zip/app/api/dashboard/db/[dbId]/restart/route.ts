import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { restartDatabase } from "@/lib/db-service";
import { getCurrentUser } from "@/lib/session";
import { enforceCooldown, getDashboardCooldownMs } from "@/lib/security";

export async function POST(_: Request, { params }: { params: { dbId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ message: "Unauthorized." }, { status: 401 });
    }
    const database = await prisma.dbInstance.findUniqueOrThrow({ where: { id: params.dbId } });
    if (database.ownerId !== user.id) {
      return NextResponse.json({ message: "Forbidden." }, { status: 403 });
    }
    const cooldown = enforceCooldown(`dashboard:restart:${user.id}:${params.dbId}`, getDashboardCooldownMs());
    if (!cooldown.allowed) {
      return NextResponse.json({ message: `Restart cooldown active. Retry in ${cooldown.retryAfter}s.` }, { status: 429 });
    }
    await restartDatabase(params.dbId);
    return NextResponse.json({ message: "Database restarted." });
  } catch {
    return NextResponse.json({ message: "Failed to restart database." }, { status: 400 });
  }
}
