import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { regenerateDatabaseApiKey } from "@/lib/db-service";
import { getCurrentUser } from "@/lib/session";
import { enforceCooldown, getDeployCooldownMs } from "@/lib/security";

export async function POST(_: Request, { params }: { params: { dbId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ message: "Unauthorized." }, { status: 401 });
    }

    const database = await prisma.dbInstance.findUniqueOrThrow({ where: { id: params.dbId } });
    if (database.ownerId !== user.id) {
      return NextResponse.json({ message: "Forbidden." }, { status: 403 });
    }

    const cooldown = enforceCooldown(`dashboard:regenerate-key:${user.id}:${params.dbId}`, getDeployCooldownMs());
    if (!cooldown.allowed) {
      return NextResponse.json({ message: `API key cooldown active. Retry in ${cooldown.retryAfter}s.` }, { status: 429 });
    }

    const result = await regenerateDatabaseApiKey(params.dbId);
    return NextResponse.json({
      message: `API key regenerated. Save it now: ${result.apiKey}`
    });
  } catch {
    return NextResponse.json({ message: "Failed to regenerate API key." }, { status: 400 });
  }
}
