import { NextRequest, NextResponse } from "next/server";
import { listCollectionDocuments, upsertCollectionDocument } from "@/lib/db-service";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/session";
import { assertJsonObject } from "@/lib/security";

export async function GET(request: NextRequest, { params }: { params: { dbId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ message: "Unauthorized." }, { status: 401 });
    }
    const collectionName = request.nextUrl.searchParams.get("collection") ?? "profiles";
    const database = await prisma.dbInstance.findUniqueOrThrow({ where: { id: params.dbId } });

    if (database.ownerId !== user.id) {
      return NextResponse.json({ message: "Forbidden." }, { status: 403 });
    }

    const documents = await listCollectionDocuments(database.publicId, collectionName);
    return NextResponse.json({ documents });
  } catch {
    return NextResponse.json({ message: "Failed to list documents." }, { status: 400 });
  }
}

export async function POST(request: NextRequest, { params }: { params: { dbId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ message: "Unauthorized." }, { status: 401 });
    }
    const body = await request.json();
    const database = await prisma.dbInstance.findUniqueOrThrow({ where: { id: params.dbId } });

    if (database.ownerId !== user.id) {
      return NextResponse.json({ message: "Forbidden." }, { status: 403 });
    }

    await upsertCollectionDocument({
      dbPublicId: database.publicId,
      collectionName: body.collection,
      data: assertJsonObject(body.data),
      ownerId: user.id,
      documentId: body.documentId
    });

    return NextResponse.json({ message: "Document saved." });
  } catch (error) {
    return NextResponse.json(
      {
        message: error instanceof Error ? error.message : "Failed to save document."
      },
      { status: 400 }
    );
  }
}
