import { NextRequest, NextResponse } from "next/server";
import { deployDatabase } from "@/lib/db-service";
import { getCurrentUser } from "@/lib/session";
import { enforceCooldown, getDeployCooldownMs } from "@/lib/security";

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ message: "Unauthorized." }, { status: 401 });
    }

    const cooldown = enforceCooldown(`dashboard:deploy:${user.id}`, getDeployCooldownMs());
    if (!cooldown.allowed) {
      return NextResponse.json(
        { message: `Deploy cooldown active. Retry in ${cooldown.retryAfter}s.` },
        { status: 429 }
      );
    }

    const body = await request.json();
    const result = await deployDatabase({
      ownerId: user.id,
      name: body.name,
      planSlug: body.planSlug ?? user.plan?.slug ?? "starter"
    });

    return NextResponse.json({
      message: "Database deployed successfully.",
      apiKey: result.apiKey
    });
  } catch (error) {
    return NextResponse.json(
      {
        message: error instanceof Error ? error.message : "Failed to deploy database."
      },
      { status: 400 }
    );
  }
}
