import { NextResponse } from "next/server";
import { DbStatus } from "@prisma/client";
import { changeDatabaseStatus } from "@/lib/db-service";
import { getCurrentAdmin } from "@/lib/session";
import { enforceCooldown, getDashboardCooldownMs } from "@/lib/security";

export async function POST(_: Request, { params }: { params: { dbId: string } }) {
  try {
    const admin = await getCurrentAdmin();
    if (!admin) {
      return NextResponse.json({ message: "Forbidden." }, { status: 403 });
    }
    const cooldown = enforceCooldown(`admin:suspend:${admin.id}:${params.dbId}`, getDashboardCooldownMs());
    if (!cooldown.allowed) {
      return NextResponse.json({ message: `Suspend cooldown active. Retry in ${cooldown.retryAfter}s.` }, { status: 429 });
    }
    await changeDatabaseStatus(params.dbId, DbStatus.SUSPENDED, "Suspended by admin.");
    return NextResponse.json({ message: "Database suspended." });
  } catch {
    return NextResponse.json({ message: "Failed to suspend database." }, { status: 400 });
  }
}
