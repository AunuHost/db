import { NextResponse } from "next/server";
import { redeployDatabase } from "@/lib/db-service";
import { getCurrentAdmin } from "@/lib/session";
import { enforceCooldown, getDeployCooldownMs } from "@/lib/security";

export async function POST(_: Request, { params }: { params: { dbId: string } }) {
  try {
    const admin = await getCurrentAdmin();
    if (!admin) {
      return NextResponse.json({ message: "Forbidden." }, { status: 403 });
    }
    const cooldown = enforceCooldown(`admin:redeploy:${admin.id}:${params.dbId}`, getDeployCooldownMs());
    if (!cooldown.allowed) {
      return NextResponse.json({ message: `Redeploy cooldown active. Retry in ${cooldown.retryAfter}s.` }, { status: 429 });
    }
    const result = await redeployDatabase(params.dbId);
    return NextResponse.json({ message: `Database redeployed. New API key: ${result.apiKey}` });
  } catch {
    return NextResponse.json({ message: "Failed to redeploy database." }, { status: 400 });
  }
}
