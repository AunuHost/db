import { NextResponse } from "next/server";
import { regenerateDatabaseApiKey } from "@/lib/db-service";
import { getCurrentAdmin } from "@/lib/session";
import { enforceCooldown, getDeployCooldownMs } from "@/lib/security";

export async function POST(_: Request, { params }: { params: { dbId: string } }) {
  try {
    const admin = await getCurrentAdmin();
    if (!admin) {
      return NextResponse.json({ message: "Forbidden." }, { status: 403 });
    }

    const cooldown = enforceCooldown(`admin:regenerate-key:${admin.id}:${params.dbId}`, getDeployCooldownMs());
    if (!cooldown.allowed) {
      return NextResponse.json({ message: `API key cooldown active. Retry in ${cooldown.retryAfter}s.` }, { status: 429 });
    }

    const result = await regenerateDatabaseApiKey(params.dbId);
    return NextResponse.json({
      message: `API key regenerated. Save it now: ${result.apiKey}`
    });
  } catch {
    return NextResponse.json({ message: "Failed to regenerate API key." }, { status: 400 });
  }
}
