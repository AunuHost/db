import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/session";
import { restartDatabase } from "@/lib/db-service";
import { enforceCooldown, getDashboardCooldownMs } from "@/lib/security";

export async function POST(_: Request, { params }: { params: { dbId: string } }) {
  try {
    const admin = await getCurrentAdmin();
    if (!admin) {
      return NextResponse.json({ message: "Forbidden." }, { status: 403 });
    }
    const cooldown = enforceCooldown(`admin:restart:${admin.id}:${params.dbId}`, getDashboardCooldownMs());
    if (!cooldown.allowed) {
      return NextResponse.json({ message: `Restart cooldown active. Retry in ${cooldown.retryAfter}s.` }, { status: 429 });
    }
    await restartDatabase(params.dbId);
    return NextResponse.json({ message: "Database restarted." });
  } catch {
    return NextResponse.json({ message: "Failed to restart database." }, { status: 400 });
  }
}
