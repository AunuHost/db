import { NextRequest, NextResponse } from "next/server";
import { createPlan } from "@/lib/db-service";
import { getCurrentAdmin } from "@/lib/session";
import { enforceCooldown, getDashboardCooldownMs } from "@/lib/security";

export async function POST(request: NextRequest) {
  try {
    const admin = await getCurrentAdmin();
    if (!admin) {
      return NextResponse.json({ message: "Forbidden." }, { status: 403 });
    }
    const cooldown = enforceCooldown(`admin:plan:${admin.id}`, getDashboardCooldownMs());
    if (!cooldown.allowed) {
      return NextResponse.json({ message: `Plan cooldown active. Retry in ${cooldown.retryAfter}s.` }, { status: 429 });
    }
    const body = await request.json();
    await createPlan(body);
    return NextResponse.json({ message: "Plan created." });
  } catch (error) {
    return NextResponse.json(
      {
        message: error instanceof Error ? error.message : "Failed to create plan."
      },
      { status: 400 }
    );
  }
}
