import { NextResponse } from "next/server";
import { DbStatus } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { isMaintenanceMode } from "@/lib/security";

export async function GET() {
  const [maintenance, totalDatabases, runningDatabases, totalUsers] = await Promise.all([
    isMaintenanceMode(),
    prisma.dbInstance.count(),
    prisma.dbInstance.count({
      where: { status: DbStatus.RUNNING }
    }),
    prisma.user.count()
  ]);

  return NextResponse.json({
    status: maintenance ? "maintenance" : "operational",
    maintenance,
    users: totalUsers,
    databases: totalDatabases,
    running: runningDatabases,
    publicBaseUrl: process.env.APP_PUBLIC_BASE_URL ?? "https://db.aerodynamic.biz.id"
  });
}
