import { NextRequest, NextResponse } from "next/server";
import { logApiEvent, searchDatabaseDocuments } from "@/lib/db-service";
import { applyRateLimitHeaders, authorizePublicApiRequest } from "@/lib/public-api";

export async function POST(request: NextRequest, { params }: { params: { databaseId: string } }) {
  const auth = await authorizePublicApiRequest(request, params.databaseId);
  if (!auth.ok) {
    return auth.response;
  }

  const body = await request.json();
  const term = String(body.term ?? "").trim();
  const limit = Number(body.limit ?? 20);

  if (!term) {
    return NextResponse.json({ message: "Search term is required." }, { status: 400 });
  }

  const results = await searchDatabaseDocuments(params.databaseId, term, limit);
  await logApiEvent({
    dbId: auth.database.id,
    action: "SEARCH_DOCUMENTS",
    route: request.nextUrl.pathname,
    statusCode: 200,
    metadata: { term, limit: results.length },
    ipAddress: auth.ip,
    userAgent: request.headers.get("user-agent")
  });

  const response = NextResponse.json({
    databaseId: params.databaseId,
    term,
    count: results.length,
    results
  });

  return applyRateLimitHeaders(response, auth.rateLimit);
}
