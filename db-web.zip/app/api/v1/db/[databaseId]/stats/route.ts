import { NextRequest, NextResponse } from "next/server";
import { getPublicDatabaseStats, logApiEvent } from "@/lib/db-service";
import { applyRateLimitHeaders, authorizePublicApiRequest } from "@/lib/public-api";

export async function GET(request: NextRequest, { params }: { params: { databaseId: string } }) {
  const auth = await authorizePublicApiRequest(request, params.databaseId);
  if (!auth.ok) {
    return auth.response;
  }

  const stats = await getPublicDatabaseStats(params.databaseId);
  await logApiEvent({
    dbId: auth.database.id,
    action: "READ_STATS",
    route: request.nextUrl.pathname,
    statusCode: 200,
    ipAddress: auth.ip,
    userAgent: request.headers.get("user-agent")
  });

  const response = NextResponse.json({ stats });
  return applyRateLimitHeaders(response, auth.rateLimit);
}
