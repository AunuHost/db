import { NextRequest, NextResponse } from "next/server";
import { listDatabaseCollections, logApiEvent } from "@/lib/db-service";
import { applyRateLimitHeaders, authorizePublicApiRequest } from "@/lib/public-api";

export async function GET(request: NextRequest, { params }: { params: { databaseId: string } }) {
  const auth = await authorizePublicApiRequest(request, params.databaseId);
  if (!auth.ok) {
    return auth.response;
  }

  const collections = await listDatabaseCollections(params.databaseId);
  await logApiEvent({
    dbId: auth.database.id,
    action: "LIST_COLLECTIONS",
    route: request.nextUrl.pathname,
    statusCode: 200,
    ipAddress: auth.ip,
    userAgent: request.headers.get("user-agent")
  });

  const response = NextResponse.json({
    databaseId: params.databaseId,
    collections: collections.map((collection) => ({
      id: collection.id,
      name: collection.name,
      slug: collection.slug,
      updatedAt: collection.updatedAt,
      documentCount: collection._count.documents
    }))
  });

  return applyRateLimitHeaders(response, auth.rateLimit);
}
