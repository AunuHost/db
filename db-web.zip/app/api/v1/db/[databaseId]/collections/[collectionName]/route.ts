import { NextRequest, NextResponse } from "next/server";
import { deleteCollectionDocument, listCollectionDocuments, logApiEvent, upsertCollectionDocument } from "@/lib/db-service";
import { applyRateLimitHeaders, authorizePublicApiRequest } from "@/lib/public-api";
import { assertJsonObject } from "@/lib/security";

export async function GET(request: NextRequest, { params }: { params: { databaseId: string; collectionName: string } }) {
  const auth = await authorizePublicApiRequest(request, params.databaseId);
  if (!auth.ok) {
    return auth.response;
  }

  const documents = await listCollectionDocuments(params.databaseId, params.collectionName);
  await logApiEvent({
    dbId: auth.database.id,
    action: "LIST_COLLECTION",
    route: request.nextUrl.pathname,
    statusCode: 200,
    ipAddress: auth.ip,
    userAgent: request.headers.get("user-agent")
  });

  const response = NextResponse.json({
    databaseId: params.databaseId,
    collection: params.collectionName,
    documents
  });
  return applyRateLimitHeaders(response, auth.rateLimit);
}

export async function POST(request: NextRequest, { params }: { params: { databaseId: string; collectionName: string } }) {
  const auth = await authorizePublicApiRequest(request, params.databaseId);
  if (!auth.ok) {
    return auth.response;
  }

  const body = await request.json();
  const document = await upsertCollectionDocument({
    dbPublicId: params.databaseId,
    collectionName: params.collectionName,
    data: assertJsonObject(body.data),
    ownerId: auth.database.ownerId,
    documentId: body.documentId
  });

  await logApiEvent({
    dbId: auth.database.id,
    action: "UPSERT_DOCUMENT",
    route: request.nextUrl.pathname,
    statusCode: 200,
    metadata: { documentId: document.id },
    ipAddress: auth.ip,
    userAgent: request.headers.get("user-agent")
  });

  const response = NextResponse.json({ message: "Document saved.", documentId: document.id });
  return applyRateLimitHeaders(response, auth.rateLimit);
}

export async function PUT(request: NextRequest, { params }: { params: { databaseId: string; collectionName: string } }) {
  const auth = await authorizePublicApiRequest(request, params.databaseId);
  if (!auth.ok) {
    return auth.response;
  }

  const body = await request.json();
  const document = await upsertCollectionDocument({
    dbPublicId: params.databaseId,
    collectionName: params.collectionName,
    data: assertJsonObject(body.data),
    ownerId: auth.database.ownerId,
    documentId: body.documentId
  });

  await logApiEvent({
    dbId: auth.database.id,
    action: "UPDATE_DOCUMENT",
    route: request.nextUrl.pathname,
    statusCode: 200,
    metadata: { documentId: document.id },
    ipAddress: auth.ip,
    userAgent: request.headers.get("user-agent")
  });

  const response = NextResponse.json({ message: "Document updated.", documentId: document.id });
  return applyRateLimitHeaders(response, auth.rateLimit);
}

export async function DELETE(request: NextRequest, { params }: { params: { databaseId: string } }) {
  const auth = await authorizePublicApiRequest(request, params.databaseId);
  if (!auth.ok) {
    return auth.response;
  }

  const documentId = request.nextUrl.searchParams.get("documentId");
  if (!documentId) {
    return NextResponse.json({ message: "documentId is required." }, { status: 400 });
  }

  await deleteCollectionDocument(documentId);
  await logApiEvent({
    dbId: auth.database.id,
    action: "DELETE_DOCUMENT",
    route: request.nextUrl.pathname,
    statusCode: 200,
    metadata: { documentId },
    ipAddress: auth.ip,
    userAgent: request.headers.get("user-agent")
  });

  const response = NextResponse.json({ message: "Document deleted." });
  return applyRateLimitHeaders(response, auth.rateLimit);
}
