import { NextRequest, NextResponse } from "next/server";
import { logApiEvent } from "@/lib/db-service";
import { applyRateLimitHeaders, authorizePublicApiRequest } from "@/lib/public-api";
import { isMaintenanceMode } from "@/lib/security";

export async function GET(request: NextRequest, { params }: { params: { databaseId: string } }) {
  const auth = await authorizePublicApiRequest(request, params.databaseId);
  if (!auth.ok) {
    return auth.response;
  }

  const maintenance = await isMaintenanceMode();

  await logApiEvent({
    dbId: auth.database.id,
    action: "READ_HEALTH",
    route: request.nextUrl.pathname,
    statusCode: 200,
    ipAddress: auth.ip,
    userAgent: request.headers.get("user-agent")
  });

  const response = NextResponse.json({
    databaseId: params.databaseId,
    status: auth.database.status,
    maintenance,
    endpoint: auth.database.endpoint,
    deploymentCount: auth.database.deploymentCount,
    storageLimitMb: auth.database.storageLimitMb,
    usedStorageMb: auth.database.usedStorageMb,
    instanceId: auth.database.id
  });

  return applyRateLimitHeaders(response, auth.rateLimit);
}
