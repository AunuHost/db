import { NextRequest, NextResponse } from "next/server";
import { exportDatabaseBundle, logApiEvent } from "@/lib/db-service";
import { applyRateLimitHeaders, authorizePublicApiRequest } from "@/lib/public-api";

export async function GET(request: NextRequest, { params }: { params: { databaseId: string } }) {
  const auth = await authorizePublicApiRequest(request, params.databaseId);
  if (!auth.ok) {
    return auth.response;
  }

  const bundle = await exportDatabaseBundle(params.databaseId);
  await logApiEvent({
    dbId: auth.database.id,
    action: "EXPORT_DATABASE",
    route: request.nextUrl.pathname,
    statusCode: 200,
    ipAddress: auth.ip,
    userAgent: request.headers.get("user-agent")
  });

  const response = NextResponse.json(bundle);
  response.headers.set("Content-Disposition", `attachment; filename="${params.databaseId}-export.json"`);
  return applyRateLimitHeaders(response, auth.rateLimit);
}
