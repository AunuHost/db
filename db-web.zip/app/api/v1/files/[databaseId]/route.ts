import { NextRequest, NextResponse } from "next/server";
import { deleteFileEntry, logApiEvent, upsertFileEntry } from "@/lib/db-service";
import { applyRateLimitHeaders, authorizePublicApiRequest } from "@/lib/public-api";
import { prisma } from "@/lib/prisma";

export async function GET(request: NextRequest, { params }: { params: { databaseId: string } }) {
  const auth = await authorizePublicApiRequest(request, params.databaseId);
  if (!auth.ok) {
    return auth.response;
  }

  const files = await prisma.fileEntry.findMany({
    where: { dbId: auth.database.id },
    orderBy: { path: "asc" }
  });

  await logApiEvent({
    dbId: auth.database.id,
    action: "LIST_FILES",
    route: request.nextUrl.pathname,
    statusCode: 200,
    ipAddress: auth.ip,
    userAgent: request.headers.get("user-agent")
  });

  const response = NextResponse.json({ files });
  return applyRateLimitHeaders(response, auth.rateLimit);
}

export async function POST(request: NextRequest, { params }: { params: { databaseId: string } }) {
  const auth = await authorizePublicApiRequest(request, params.databaseId);
  if (!auth.ok) {
    return auth.response;
  }

  const body = await request.json();
  const file = await upsertFileEntry(auth.database.id, auth.database.ownerId, body);

  await logApiEvent({
    dbId: auth.database.id,
    action: "UPSERT_FILE",
    route: request.nextUrl.pathname,
    statusCode: 200,
    metadata: { path: file.path },
    ipAddress: auth.ip,
    userAgent: request.headers.get("user-agent")
  });

  const response = NextResponse.json({ message: "File saved.", path: file.path });
  return applyRateLimitHeaders(response, auth.rateLimit);
}

export async function DELETE(request: NextRequest, { params }: { params: { databaseId: string } }) {
  const auth = await authorizePublicApiRequest(request, params.databaseId);
  if (!auth.ok) {
    return auth.response;
  }

  const path = request.nextUrl.searchParams.get("path");
  if (!path) {
    return NextResponse.json({ message: "path is required." }, { status: 400 });
  }

  await deleteFileEntry(auth.database.id, path);

  await logApiEvent({
    dbId: auth.database.id,
    action: "DELETE_FILE",
    route: request.nextUrl.pathname,
    statusCode: 200,
    metadata: { path },
    ipAddress: auth.ip,
    userAgent: request.headers.get("user-agent")
  });

  const response = NextResponse.json({ message: "File deleted.", path });
  return applyRateLimitHeaders(response, auth.rateLimit);
}
