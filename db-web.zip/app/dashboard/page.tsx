import Link from "next/link";
import { CollectionManager } from "@/components/collection-manager";
import { CopyButton } from "@/components/copy-button";
import { DatabaseActions } from "@/components/database-actions";
import { FileManager } from "@/components/file-manager";
import { LaunchDatabaseForm } from "@/components/launch-database-form";
import { MetricCard } from "@/components/metric-card";
import { StatusPill } from "@/components/status-pill";
import { getDatabaseStats } from "@/lib/db-service";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import { formatDate, formatNumber } from "@/lib/utils";

export default async function DashboardPage() {
  const user = await requireUser();
  const database = await prisma.dbInstance.findFirst({
    where: { ownerId: user.id },
    orderBy: { createdAt: "desc" }
  });

  if (!database) {
    return (
      <section className="section">
        <div className="container">
          <div className="dashboard-head">
            <div>
              <p className="eyebrow">User Dashboard</p>
              <h1>No active database yet</h1>
              <p>User ID: {user.id}</p>
            </div>
          </div>
          <LaunchDatabaseForm defaultPlan={user.plan?.slug ?? "starter"} />
        </div>
      </section>
    );
  }

  const stats = await getDatabaseStats(database.id);

  return (
    <section className="section">
      <div className="container dashboard-grid">
        <div className="dashboard-head wide">
          <div>
            <p className="eyebrow">User Dashboard</p>
            <h1>{stats.database.name}</h1>
            <p>
              User ID: {user.id} | Discord ID: {user.discordId} | Plan: {stats.database.plan.name}
            </p>
          </div>
          <div className="inline-actions">
            <StatusPill status={stats.database.status} />
            <CopyButton label="Copy Endpoint" value={stats.database.endpoint} />
          </div>
        </div>

        <div className="metrics-grid">
          <MetricCard label="Storage Used" value={`${stats.database.usedStorageMb.toFixed(2)} MB`} helper={`Limit ${stats.database.storageLimitMb} MB`} />
          <MetricCard label="Collections" value={formatNumber(stats.totalCollections)} />
          <MetricCard label="Documents" value={formatNumber(stats.totalDocuments)} />
          <MetricCard label="Files" value={formatNumber(stats.totalFiles)} />
          <MetricCard label="Deploy Count" value={formatNumber(stats.database.deploymentCount)} />
          <MetricCard label="Recent Requests" value={formatNumber(stats.recentRequests)} />
        </div>

        <div className="card">
          <div className="section-head">
            <div>
              <p className="eyebrow">Connection</p>
              <h2>Bot and app integration</h2>
            </div>
          </div>
          <div className="connection-grid">
            <div>
              <span>Endpoint</span>
              <code>{stats.database.endpoint}</code>
            </div>
            <div>
              <span>API Key Preview</span>
              <code>{stats.database.apiKeyPreview}</code>
            </div>
            <div>
              <span>Last Deploy</span>
              <code>{formatDate(stats.database.lastDeployAt)}</code>
            </div>
            <div>
              <span>Monitor</span>
              <code>{stats.latestSnapshot ? `${stats.latestSnapshot.uptimePercent}% uptime` : "No snapshot available yet"}</code>
            </div>
          </div>
          <p className="hint">
            API keys stay masked after creation. Use <strong>Regenerate API Key</strong> to issue a new key and copy it
            immediately.
          </p>
          <DatabaseActions dbId={stats.database.id} />
        </div>

        <div className="card">
          <div className="section-head">
            <div>
              <p className="eyebrow">Security</p>
              <h2>Active guardrails</h2>
            </div>
          </div>
          <ul className="feature-list">
            <li>Public API anti-flood protection based on the requester IP and plan limits</li>
            <li>Dashboard cooldowns for start, stop, restart, redeploy, and deploy actions</li>
            <li>Storage quotas are checked automatically before file or document writes</li>
            <li>Path traversal and oversized payloads are rejected</li>
            <li>Suspended or stopped databases do not accept public requests</li>
          </ul>
        </div>

        <div className="card">
          <div className="section-head">
            <div>
              <p className="eyebrow">Recent Audit</p>
              <h2>Latest request log</h2>
            </div>
            <Link href="/docs" className="inline-link">
              API docs
            </Link>
          </div>

          <div className="table-shell">
            <table>
              <thead>
                <tr>
                  <th>Action</th>
                  <th>Route</th>
                  <th>Status</th>
                  <th>Time</th>
                </tr>
              </thead>
              <tbody>
                {stats.database.apiLogs.map((log) => (
                  <tr key={log.id}>
                    <td>{log.action}</td>
                    <td>{log.route}</td>
                    <td>{log.statusCode}</td>
                    <td>{formatDate(log.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <CollectionManager databaseId={stats.database.id} />
        <FileManager databaseId={stats.database.id} files={stats.database.files} />
      </div>
    </section>
  );
}
