import { LoginButton } from "@/components/login-button";
import { getInviteUrl } from "@/lib/env";

export default function LoginPage() {
  return (
    <section className="section narrow-section">
      <div className="container">
        <div className="card login-card">
          <p className="eyebrow">Discord Authentication</p>
          <h1>Sign in with Discord only</h1>
          <p>
            After sign-in, the system will try to add the user to the Discord community automatically. If guild join permission
            is not active yet, the user will still be redirected to the official invite.
          </p>
          <div className="inline-actions">
            <LoginButton />
            <a href={getInviteUrl()} className="button subtle-button" target="_blank" rel="noreferrer">
              Join Discord
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
