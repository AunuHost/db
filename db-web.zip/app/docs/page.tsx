import { prisma } from "@/lib/prisma";
import { FEATURE_CATALOG } from "@/lib/constants";

export default async function DocsPage() {
  const plans = await prisma.plan.findMany({ orderBy: { priceMonthly: "asc" } });

  return (
    <section className="section">
      <div className="container docs-grid">
        <div className="card">
          <p className="eyebrow">Quick Start</p>
          <h1>API key and database usage docs</h1>
          <p>All public access uses the `https://db.loudness.biz.id` endpoint and the database owner's `x-api-key` header.</p>
          <pre>
            <code>{`curl -X GET "https://db.loudness.biz.id/api/v1/db/db_xxxxx/collections/profiles" \\
  -H "x-api-key: ldb_your_private_key"`}</code>
          </pre>
          <pre>
            <code>{`curl -X POST "https://db.loudness.biz.id/api/v1/db/db_xxxxx/collections/profiles" \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: ldb_your_private_key" \\
  -d '{"data":{"discordId":"123","coins":420}}'`}</code>
          </pre>
          <pre>
            <code>{`curl -X POST "https://db.loudness.biz.id/api/v1/files/db_xxxxx" \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: ldb_your_private_key" \\
  -d '{"path":"/config/bot.json","type":"FILE","content":"{\\"prefix\\":\\"!\\"}"}'`}</code>
          </pre>
          <pre>
            <code>{`curl -X GET "https://db.loudness.biz.id/api/v1/db/db_xxxxx/stats" \\
  -H "x-api-key: ldb_your_private_key"`}</code>
          </pre>
          <pre>
            <code>{`curl -X POST "https://db.loudness.biz.id/api/v1/db/db_xxxxx/search" \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: ldb_your_private_key" \\
  -d '{"term":"coins","limit":10}'`}</code>
          </pre>
        </div>

        <div className="card">
          <p className="eyebrow">Capabilities</p>
          <h2>What is supported</h2>
          <ul className="feature-list">
            <li>Collection CRUD for bots and third-party applications</li>
            <li>File manager API and direct dashboard editing</li>
            <li>Usage snapshots, request logs, status, and storage monitoring</li>
            <li>Discord-only dashboard auth with admin and owner roles</li>
            <li>Deploy, stop, start, restart, suspend, and redeploy operations</li>
            <li>Simple USD-based plan billing</li>
            <li>Status page and incident notes</li>
            <li>Discord bot command set for owner, admin, and user roles</li>
            <li>Plan and IP-based anti-flood API protection</li>
            <li>Cooldowns for start, stop, restart, redeploy, and deploy actions</li>
            <li>Collection name validation, file path validation, and payload size limits</li>
            <li>Public stats, health, export, search, and collection list endpoints</li>
          </ul>
        </div>

        <div className="card">
          <p className="eyebrow">Plans</p>
          <h2>Default pricing</h2>
          <div className="stack-list">
            {plans.map((plan) => (
              <div key={plan.id}>
                <strong>{plan.name}</strong>
                <span>
                  ${plan.priceMonthly}/month | {plan.storageLimitMb} MB | {plan.deployLimit} active deployment
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <p className="eyebrow">Security Defaults</p>
          <h2>Built-in platform hardening</h2>
          <ul className="feature-list">
            <li>`X-RateLimit-*` and `Retry-After` headers on the public API</li>
            <li>Per-database, per-IP rate limiting based on plan limits</li>
            <li>IP deny list via the `SECURITY_BLOCKED_IPS` env variable</li>
            <li>Path traversal blocked on the file manager API</li>
            <li>Maximum size limits for documents and files</li>
            <li>Storage quotas enforced before every write</li>
            <li>Maintenance mode blocks public API access</li>
            <li>Suspended and stopped databases do not serve public traffic</li>
            <li>Slash commands use anti-spam cooldowns</li>
            <li>Sensitive dashboard actions are throttled to prevent operation floods</li>
          </ul>
        </div>

        <div className="card">
          <p className="eyebrow">Extra Surface</p>
          <h2>Dozens of platform features</h2>
          <div className="feature-cloud">
            {FEATURE_CATALOG.map((feature) => (
              <span key={feature}>{feature}</span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
