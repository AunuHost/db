import { AdminDbActions } from "@/components/admin-db-actions";
import { AdminPlanForm } from "@/components/admin-plan-form";
import { MetricCard } from "@/components/metric-card";
import { StatusPill } from "@/components/status-pill";
import { getAdminOverview } from "@/lib/db-service";
import { requireAdmin } from "@/lib/session";
import { formatCurrency, formatDate } from "@/lib/utils";

export default async function AdminPage() {
  await requireAdmin();
  const overview = await getAdminOverview();

  return (
    <section className="section">
      <div className="container dashboard-grid">
        <div className="dashboard-head wide">
          <div>
            <p className="eyebrow">Admin Dashboard</p>
            <h1>Full monitoring and control</h1>
            <p>Every user, database, plan, and maintenance state can be monitored from here.</p>
          </div>
          <StatusPill status={overview.maintenanceMode ? "maintenance" : "operational"} />
        </div>

        <div className="metrics-grid">
          <MetricCard label="Users" value={String(overview.stats.users)} />
          <MetricCard label="Admins" value={String(overview.stats.admins)} />
          <MetricCard label="Databases" value={String(overview.stats.databases)} />
          <MetricCard label="Running" value={String(overview.stats.running)} />
          <MetricCard label="Suspended" value={String(overview.stats.suspended)} />
          <MetricCard label="Maintenance" value={overview.maintenanceMode ? "On" : "Off"} />
        </div>

        <div className="card">
          <div className="section-head">
            <div>
              <p className="eyebrow">Plans</p>
              <h2>Pricing and quotas</h2>
            </div>
          </div>
          <div className="table-shell">
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Price</th>
                  <th>Storage</th>
                  <th>Deploys</th>
                </tr>
              </thead>
              <tbody>
                {overview.plans.map((plan) => (
                  <tr key={plan.id}>
                    <td>{plan.name}</td>
                    <td>{formatCurrency(plan.priceMonthly)}</td>
                    <td>{plan.storageLimitMb} MB</td>
                    <td>{plan.deployLimit}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <AdminPlanForm />

        <div className="card">
          <div className="section-head">
            <div>
              <p className="eyebrow">Security Surface</p>
              <h2>Platform protection</h2>
            </div>
          </div>
          <ul className="feature-list">
            <li>Public API anti-flood protection based on IP and plan limits</li>
            <li>Admin action cooldowns for start, stop, restart, redeploy, and suspend</li>
            <li>Security headers via middleware for both web and API traffic</li>
            <li>Payload size limits for documents and file manager operations</li>
            <li>IP deny lists and maintenance gates configurable through env and settings</li>
          </ul>
        </div>

        <div className="card">
          <div className="section-head">
            <div>
              <p className="eyebrow">Database Fleet</p>
              <h2>Monitor every database</h2>
            </div>
          </div>
          <p className="hint">
            API keys remain masked in the dashboard. Use <strong>Regenerate API Key</strong> when you need to rotate and
            reveal a fresh key once.
          </p>
          <div className="table-shell">
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Owner</th>
                  <th>Plan</th>
                  <th>Status</th>
                  <th>Last Deploy</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {overview.databases.map((database) => (
                  <tr key={database.id}>
                    <td>{database.name}</td>
                    <td>
                      {database.owner.username}
                      <small>{database.owner.discordId}</small>
                    </td>
                    <td>{database.plan.name}</td>
                    <td>
                      <StatusPill status={database.status} />
                    </td>
                    <td>{formatDate(database.lastDeployAt)}</td>
                    <td>
                      <AdminDbActions dbId={database.id} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card">
          <div className="section-head">
            <div>
              <p className="eyebrow">User Roster</p>
              <h2>User profiles for admins</h2>
            </div>
          </div>
          <div className="table-shell">
            <table>
              <thead>
                <tr>
                  <th>Username</th>
                  <th>User ID</th>
                  <th>Discord ID</th>
                  <th>Role</th>
                  <th>Plan</th>
                  <th>Joined</th>
                </tr>
              </thead>
              <tbody>
                {overview.users.map((user) => (
                  <tr key={user.id}>
                    <td>{user.globalName ?? user.username}</td>
                    <td>{user.id}</td>
                    <td>{user.discordId}</td>
                    <td>{user.role}</td>
                    <td>{user.plan?.name ?? "-"}</td>
                    <td>{formatDate(user.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
