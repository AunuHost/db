import Link from "next/link";
import { ArrowRight, Database, ShieldCheck, Bot, FolderKanban, Activity, KeyRound } from "lucide-react";
import { PlanCard } from "@/components/plan-card";
import { FEATURE_CATALOG } from "@/lib/constants";
import { prisma } from "@/lib/prisma";

const heroFeatures = [
  {
    title: "Deploy once, manage everything",
    description: "Each user gets one active deployment based on their plan, complete with a private database endpoint.",
    icon: Database
  },
  {
    title: "Private API keys, bot-ready",
    description: "Discord bots and external integrations can read, create, update, and delete data using private API keys.",
    icon: KeyRound
  },
  {
    title: "Full monitoring",
    description: "Track collections, files, usage snapshots, request logs, and health status from one dashboard.",
    icon: Activity
  },
  {
    title: "Admin control center",
    description: "Admins can deploy, stop, restart, suspend, create plans, and audit every user database.",
    icon: ShieldCheck
  },
  {
    title: "Built-in file manager",
    description: "Every database has its own file space for config, schema, cache, and bot archives.",
    icon: FolderKanban
  },
  {
    title: "Discord onboarding",
    description: "Authentication is Discord-only, and the system attempts to auto-join users to the community server.",
    icon: Bot
  }
];

export default async function HomePage() {
  const plans = await prisma.plan.findMany({
    orderBy: { priceMonthly: "asc" }
  });

  return (
    <>
      <section className="hero-section">
        <div className="container hero-grid">
          <div>
            <p className="eyebrow">Database Hosting Platform</p>
            <h1>As simple as MongoDB Cloud, as polished as a modern infra dashboard.</h1>
            <p className="hero-copy">
              Loudness DB is a hosted document database platform with Discord-only login, private API keys, a file manager,
              bot controls, a status page, and admin monitoring, ready to run on a VPS on port 8999 behind Cloudflare Tunnel.
            </p>
            <div className="inline-actions">
              <Link href="/login" className="button button-primary">
                Continue with Discord
              </Link>
              <Link href="/docs" className="button subtle-button">
                Open Docs
              </Link>
            </div>
            <div className="hero-meta">
              <span>Public URL: https://db.aerodynamic.biz.id</span>
              <span>Bind: 0.0.0.0:8999</span>
              <span>Discord only auth</span>
            </div>
          </div>

          <div className="hero-panel">
            <div className="glass-panel">
              <div className="section-head">
                <div>
                  <p className="eyebrow">Live Overview</p>
                  <h3>What ships in this build</h3>
                </div>
              </div>
              <div className="stack-list">
                <div>
                  <strong>User Dashboard</strong>
                  <span>Deployment, monitoring, collection manager, file manager, API preview.</span>
                </div>
                <div>
                  <strong>Admin Dashboard</strong>
                  <span>Plan management, full monitoring, database controls, roster visibility.</span>
                </div>
                <div>
                  <strong>Discord Bot</strong>
                  <span>Owner, admin, and user slash commands with deploy/start/stop/redeploy flows.</span>
                </div>
              </div>
              <Link href="/dashboard" className="inline-link">
                Open platform <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container cards-grid">
          {heroFeatures.map((feature) => (
            <article className="card feature-card" key={feature.title}>
              <feature.icon size={20} />
              <h3>{feature.title}</h3>
              <p>{feature.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section section-dark">
        <div className="container">
          <div className="section-head">
            <div>
              <p className="eyebrow">Feature Stack</p>
              <h2>Dozens of core features a real database platform actually needs</h2>
            </div>
          </div>
          <div className="feature-cloud">
            {FEATURE_CATALOG.map((feature) => (
              <span key={feature}>{feature}</span>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-head">
            <div>
              <p className="eyebrow">Plans</p>
              <h2>Starter, Business, Enterprise</h2>
            </div>
          </div>
          <div className="cards-grid plan-grid">
            {plans.map((plan) => (
              <PlanCard key={plan.id} plan={plan} />
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
