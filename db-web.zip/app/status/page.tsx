import { StatusPill } from "@/components/status-pill";
import { prisma } from "@/lib/prisma";
import { formatDate } from "@/lib/utils";

export default async function StatusPage() {
  const [incidents, databases, maintenance] = await Promise.all([
    prisma.statusIncident.findMany({
      orderBy: { createdAt: "desc" },
      take: 10
    }),
    prisma.dbInstance.findMany(),
    prisma.systemSetting.findUnique({
      where: { key: "maintenance_mode" }
    })
  ]);

  const running = databases.filter((db) => db.status === "RUNNING").length;
  const overallStatus = maintenance?.value === "true" ? "maintenance" : "operational";

  return (
    <section className="section">
      <div className="container status-grid">
        <div className="card">
          <p className="eyebrow">Platform Status</p>
          <h1>System health overview</h1>
          <div className="status-overview">
            <StatusPill status={overallStatus} />
            <span>{running} active databases</span>
            <span>{databases.length} total deployments</span>
          </div>
        </div>

        <div className="card">
          <p className="eyebrow">Incident Timeline</p>
          <div className="stack-list">
            {incidents.map((incident) => (
              <div key={incident.id}>
                <strong>{incident.title}</strong>
                <span>
                  <StatusPill status={incident.status} /> {incident.message}
                </span>
                <small>{formatDate(incident.createdAt)}</small>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
