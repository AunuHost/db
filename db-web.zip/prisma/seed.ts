import { PrismaClient, UserRole } from "@prisma/client";
import { createApiKey } from "../lib/api-key";

const prisma = new PrismaClient();

async function main() {
  const starter = await prisma.plan.upsert({
    where: { slug: "starter" },
    update: {},
    create: {
      name: "Starter",
      slug: "starter",
      description: "For small projects, personal bots, and early experiments.",
      priceMonthly: 9,
      storageLimitMb: 256,
      deployLimit: 1,
      apiRateLimit: 120,
      features: JSON.stringify([
        "1 active deployment",
        "Max 256 MB data",
        "Discord-only login",
        "Private API key",
        "Basic monitoring",
        "File manager",
        "Collection CRUD"
      ])
    }
  });

  const business = await prisma.plan.upsert({
    where: { slug: "business" },
    update: {},
    create: {
      name: "Business",
      slug: "business",
      description: "For teams, active bots, and more stable workloads.",
      priceMonthly: 29,
      storageLimitMb: 1024,
      deployLimit: 1,
      apiRateLimit: 600,
      features: JSON.stringify([
        "1 active deployment",
        "Max 1 GB data",
        "Extended metrics",
        "Priority restart",
        "More audit logs",
        "API rate upgrade",
        "Status export"
      ])
    }
  });

  await prisma.plan.upsert({
    where: { slug: "enterprise" },
    update: {},
    create: {
      name: "Enterprise",
      slug: "enterprise",
      description: "For critical workloads, admin tooling, and full monitoring.",
      priceMonthly: 99,
      storageLimitMb: 10240,
      deployLimit: 1,
      apiRateLimit: 5000,
      features: JSON.stringify([
        "1 active deployment",
        "10 GB data",
        "Advanced monitoring",
        "Incident visibility",
        "Admin priority",
        "High request throughput",
        "Custom SLA ready"
      ])
    }
  });

  await prisma.systemSetting.upsert({
    where: { key: "maintenance_mode" },
    update: {},
    create: {
      key: "maintenance_mode",
      value: "false"
    }
  });

  const incidentCount = await prisma.statusIncident.count();
  if (incidentCount === 0) {
    await prisma.statusIncident.createMany({
      data: [
        {
          title: "Cluster healthy",
          status: "operational",
          message: "All database services, auth flows, and the bot gateway are operating normally."
        },
        {
          title: "Scheduled backup check",
          status: "monitoring",
          message: "Monitoring snapshots and cold-start latency are currently being validated."
        }
      ]
    });
  }

  const ownerDiscordId = process.env.DISCORD_OWNER_ID;
  if (ownerDiscordId) {
    const apiKey = createApiKey();
    const owner = await prisma.user.upsert({
      where: { discordId: ownerDiscordId },
      update: { role: UserRole.OWNER, planId: business.id },
      create: {
        discordId: ownerDiscordId,
        username: "server-owner",
        globalName: "Server Owner",
        role: UserRole.OWNER,
        planId: business.id
      }
    });

    await prisma.dbInstance.upsert({
      where: { publicId: "db-owner-main" },
      update: {},
      create: {
        publicId: "db-owner-main",
        name: "Owner Primary DB",
        slug: "owner-primary-db",
        endpoint: `${process.env.APP_PUBLIC_BASE_URL ?? "https://db.loudness.biz.id"}/api/v1/db/db-owner-main`,
        ownerId: owner.id,
        planId: business.id,
        status: "RUNNING",
        region: process.env.DEFAULT_REGION ?? "Singapore",
        storageLimitMb: business.storageLimitMb,
        usedStorageMb: 96,
        apiKeyHash: apiKey.hash,
        apiKeyPreview: apiKey.preview,
        deploymentCount: 1,
        lastDeployAt: new Date(),
        deployedAt: new Date()
      }
    });
  }

  await prisma.$disconnect();
}

main().catch(async (error) => {
  console.error(error);
  await prisma.$disconnect();
  process.exit(1);
});
