import {
  ActionRowBuilder,
  ChatInputCommandInteraction,
  Client,
  EmbedBuilder,
  GatewayIntentBits,
  REST,
  Routes,
  SlashCommandBuilder,
  StringSelectMenuBuilder
} from "discord.js";
import { DbStatus, PrismaClient, UserRole } from "@prisma/client";
import { changeDatabaseStatus, deployDatabase, getAdminOverview, redeployDatabase, restartDatabase, setMaintenanceMode, setUserRole } from "../lib/db-service";
import { enforceCooldown, getBlockedIps, getBotCooldownMs, getDashboardCooldownMs } from "../lib/security";

const prisma = new PrismaClient();
const ownerDiscordId = process.env.DISCORD_OWNER_ID ?? "";
const token = process.env.DISCORD_BOT_TOKEN ?? "";
const clientId = process.env.DISCORD_CLIENT_ID ?? "";

if (!token || !clientId) {
  throw new Error("Missing DISCORD_BOT_TOKEN or DISCORD_CLIENT_ID.");
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds]
});

const commands = [
  new SlashCommandBuilder()
    .setName("restart")
    .setDescription("Restart all databases or a target user/db.")
    .addStringOption((option) =>
      option
        .setName("scope")
        .setDescription("Target scope")
        .setRequired(true)
        .addChoices(
          { name: "all", value: "all" },
          { name: "userid", value: "userid" }
        )
    )
    .addStringOption((option) => option.setName("userid").setDescription("Platform user ID or Discord ID"))
    .addStringOption((option) => option.setName("db_id").setDescription("Specific database ID")),
  new SlashCommandBuilder()
    .setName("stop")
    .setDescription("Stop all databases or a target user/db.")
    .addStringOption((option) =>
      option
        .setName("scope")
        .setDescription("Target scope")
        .setRequired(true)
        .addChoices(
          { name: "all", value: "all" },
          { name: "userid", value: "userid" }
        )
    )
    .addStringOption((option) => option.setName("userid").setDescription("Platform user ID or Discord ID"))
    .addStringOption((option) => option.setName("db_id").setDescription("Specific database ID")),
  new SlashCommandBuilder()
    .setName("start")
    .setDescription("Start all databases or a target user/db.")
    .addStringOption((option) =>
      option
        .setName("scope")
        .setDescription("Target scope")
        .setRequired(true)
        .addChoices(
          { name: "all", value: "all" },
          { name: "userid", value: "userid" }
        )
    )
    .addStringOption((option) => option.setName("userid").setDescription("Platform user ID or Discord ID"))
    .addStringOption((option) => option.setName("db_id").setDescription("Specific database ID")),
  new SlashCommandBuilder()
    .setName("redeploy")
    .setDescription("Redeploy all databases or a target user/db.")
    .addStringOption((option) =>
      option
        .setName("scope")
        .setDescription("Target scope")
        .setRequired(true)
        .addChoices(
          { name: "all", value: "all" },
          { name: "userid", value: "userid" }
        )
    )
    .addStringOption((option) => option.setName("userid").setDescription("Platform user ID or Discord ID"))
    .addStringOption((option) => option.setName("db_id").setDescription("Specific database ID")),
  new SlashCommandBuilder()
    .setName("maintenance")
    .setDescription("Toggle maintenance mode.")
    .addBooleanOption((option) => option.setName("enabled").setDescription("true or false").setRequired(true)),
  new SlashCommandBuilder()
    .setName("admin")
    .setDescription("Manage admin access.")
    .addSubcommand((command) =>
      command
        .setName("create")
        .setDescription("Grant admin access to a user.")
        .addStringOption((option) => option.setName("user_id").setDescription("Platform user ID or Discord ID").setRequired(true))
    ),
  new SlashCommandBuilder()
    .setName("delete")
    .setDescription("Delete a database.")
    .addStringOption((option) => option.setName("db_id").setDescription("Database ID").setRequired(true)),
  new SlashCommandBuilder()
    .setName("deploy")
    .setDescription("Admin deploy a new database.")
    .addStringOption((option) => option.setName("userid").setDescription("Platform user ID or Discord ID").setRequired(true))
    .addIntegerOption((option) => option.setName("size").setDescription("Storage size in MB").setRequired(true)),
  new SlashCommandBuilder().setName("monitor").setDescription("Monitor all users and databases."),
  new SlashCommandBuilder()
    .setName("suspend")
    .setDescription("Suspend a database.")
    .addStringOption((option) => option.setName("db_id").setDescription("Database ID").setRequired(true)),
  new SlashCommandBuilder().setName("link").setDescription("Show your database link and registration status."),
  new SlashCommandBuilder().setName("manage").setDescription("Manage your databases via embed selection."),
  new SlashCommandBuilder().setName("ping").setDescription("Bot latency check.")
].map((command) => command.toJSON());

async function registerCommands() {
  const rest = new REST({ version: "10" }).setToken(token);
  await rest.put(Routes.applicationCommands(clientId), { body: commands });
}

function normalizeLookupId(id: string) {
  return id.replace(/[<@!>]/g, "").trim();
}

async function findUserByAnyId(id: string) {
  const normalized = normalizeLookupId(id);
  return prisma.user.findFirst({
    where: {
      OR: [{ id: normalized }, { discordId: normalized }]
    }
  });
}

async function ensureOwner(interaction: ChatInputCommandInteraction) {
  if (interaction.user.id !== ownerDiscordId) {
    await interaction.reply({ content: "Owner only command.", ephemeral: true });
    return false;
  }
  return true;
}

async function ensureCommandCooldown(interaction: ChatInputCommandInteraction) {
  const cooldown = enforceCooldown(`bot:${interaction.user.id}:${interaction.commandName}`, getBotCooldownMs());
  if (!cooldown.allowed) {
    await interaction.reply({
      content: `Anti-flood protection is active. Try again in ${cooldown.retryAfter} seconds.`,
      ephemeral: true
    });
    return false;
  }

  return true;
}

async function ensureAdmin(interaction: ChatInputCommandInteraction) {
  if (interaction.user.id === ownerDiscordId) {
    return true;
  }

  const user = await prisma.user.findUnique({
    where: { discordId: interaction.user.id }
  });

  if (!user || (user.role !== UserRole.ADMIN && user.role !== UserRole.OWNER)) {
    await interaction.reply({ content: "Admin only command.", ephemeral: true });
    return false;
  }

  return true;
}

async function applyDbAction(targets: Array<{ id: string }>, action: "start" | "stop" | "restart" | "redeploy") {
  const results: string[] = [];

  for (const target of targets) {
    if (action === "start") {
      await changeDatabaseStatus(target.id, DbStatus.RUNNING);
    }
    if (action === "stop") {
      await changeDatabaseStatus(target.id, DbStatus.STOPPED);
    }
    if (action === "restart") {
      await restartDatabase(target.id);
    }
    if (action === "redeploy") {
      const result = await redeployDatabase(target.id);
      results.push(`${target.id}: ${result.apiKey}`);
      continue;
    }
    results.push(target.id);
  }

  return results;
}

async function resolveTargetDatabases(scope: string, userId?: string | null, dbId?: string | null) {
  if (scope === "all") {
    return prisma.dbInstance.findMany({
      select: { id: true }
    });
  }

  const user = userId ? await findUserByAnyId(userId) : null;
  if (!user) {
    throw new Error("User not found.");
  }

  return prisma.dbInstance.findMany({
    where: {
      ownerId: user.id,
      ...(dbId ? { id: dbId } : {})
    },
    select: { id: true }
  });
}

client.once("ready", async () => {
  await registerCommands();
  console.log(`Bot logged in as ${client.user?.tag}`);
});

client.on("interactionCreate", async (interaction) => {
  if (interaction.isStringSelectMenu()) {
    if (!interaction.customId.startsWith("manage-db:")) {
      return;
    }

    const dbId = interaction.values[0];
    const database = await prisma.dbInstance.findUnique({
      where: { id: dbId },
      include: {
        usageSnapshots: {
          orderBy: { createdAt: "desc" },
          take: 1
        }
      }
    });

    if (!database) {
      await interaction.reply({ content: "Database not found.", ephemeral: true });
      return;
    }

    const snapshot = database.usageSnapshots[0];
    const embed = new EmbedBuilder()
      .setTitle(database.name)
      .setDescription(`Endpoint: ${database.endpoint}`)
      .addFields(
        { name: "Status", value: database.status, inline: true },
        { name: "Storage", value: `${database.usedStorageMb.toFixed(2)} / ${database.storageLimitMb} MB`, inline: true },
        { name: "Deploy Count", value: String(database.deploymentCount), inline: true },
        { name: "API Key", value: database.apiKeyPreview, inline: false },
        { name: "Uptime", value: snapshot ? `${snapshot.uptimePercent}%` : "No snapshot", inline: true }
      )
      .setColor(0x63e6be);

    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  if (!interaction.isChatInputCommand()) {
    return;
  }

  try {
    const cooldownAllowed = await ensureCommandCooldown(interaction);
    if (!cooldownAllowed) {
      return;
    }

    if (interaction.commandName === "ping") {
      await interaction.reply({ content: `Pong! ${client.ws.ping}ms`, ephemeral: true });
      return;
    }

    if (interaction.commandName === "link") {
      const user = await prisma.user.findUnique({
        where: { discordId: interaction.user.id }
      });

      if (!user) {
        await interaction.reply({ content: "Your account is not registered in the dashboard yet.", ephemeral: true });
        return;
      }

      const database = await prisma.dbInstance.findFirst({
        where: { ownerId: user.id }
      });

      await interaction.reply({
        content: database
          ? `Registered. Endpoint: ${database.endpoint}\nUser ID: ${user.id}\nDiscord ID: ${user.discordId}`
          : `This user is registered but does not have a database yet.\nUser ID: ${user.id}\nDiscord ID: ${user.discordId}`,
        ephemeral: true
      });
      return;
    }

    if (interaction.commandName === "manage") {
      const user = await prisma.user.findUnique({
        where: { discordId: interaction.user.id }
      });

      if (!user) {
        await interaction.reply({ content: "Dashboard account not found.", ephemeral: true });
        return;
      }

      const databases = await prisma.dbInstance.findMany({
        where: { ownerId: user.id },
        orderBy: { createdAt: "desc" }
      });

      if (databases.length === 0) {
        await interaction.reply({ content: "There are no databases to manage yet.", ephemeral: true });
        return;
      }

      const embed = new EmbedBuilder()
        .setTitle("Manage Databases")
        .setDescription("Choose a database to view its status.")
        .setColor(0x63e6be);

      const select = new StringSelectMenuBuilder()
        .setCustomId(`manage-db:${user.id}`)
        .setPlaceholder("Select a database")
        .addOptions(
          databases.map((database) => ({
            label: database.name,
            description: `${database.status} | ${database.apiKeyPreview}`,
            value: database.id
          }))
        );

      const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
      await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
      return;
    }

    if (["restart", "stop", "start", "redeploy", "maintenance", "admin", "delete"].includes(interaction.commandName)) {
      const allowed = await ensureOwner(interaction);
      if (!allowed) {
        return;
      }
    }

    if (["deploy", "monitor", "suspend"].includes(interaction.commandName)) {
      const allowed = await ensureAdmin(interaction);
      if (!allowed) {
        return;
      }
    }

    if (["restart", "stop", "start", "redeploy"].includes(interaction.commandName)) {
      const scope = interaction.options.getString("scope", true);
      const userId = interaction.options.getString("userid");
      const dbId = interaction.options.getString("db_id");
      const targets = await resolveTargetDatabases(scope, userId, dbId);
      const results = await applyDbAction(targets, interaction.commandName as "start" | "stop" | "restart" | "redeploy");
      await interaction.reply({
        content: `${interaction.commandName} executed for ${targets.length} database(s).\n${results.slice(0, 10).join("\n")}`,
        ephemeral: true
      });
      return;
    }

    if (interaction.commandName === "maintenance") {
      const enabled = interaction.options.getBoolean("enabled", true);
      await setMaintenanceMode(enabled);
      await interaction.reply({ content: `Maintenance mode set to ${enabled}.`, ephemeral: true });
      return;
    }

    if (interaction.commandName === "admin" && interaction.options.getSubcommand() === "create") {
      const userId = interaction.options.getString("user_id", true);
      const user = await findUserByAnyId(userId);
      if (!user) {
        await interaction.reply({ content: "User not found.", ephemeral: true });
        return;
      }
      await setUserRole(user.id, UserRole.ADMIN);
      await interaction.reply({ content: `User ${user.id} is now an admin.`, ephemeral: true });
      return;
    }

    if (interaction.commandName === "delete") {
      const dbId = interaction.options.getString("db_id", true);
      await prisma.dbInstance.delete({ where: { id: dbId } });
      await interaction.reply({ content: `Database ${dbId} deleted.`, ephemeral: true });
      return;
    }

    if (interaction.commandName === "deploy") {
      const userId = interaction.options.getString("userid", true);
      const size = interaction.options.getInteger("size", true);
      const user = await findUserByAnyId(userId);

      if (!user) {
        await interaction.reply({ content: "User not found.", ephemeral: true });
        return;
      }

      const plan = size <= 256 ? "starter" : size <= 1024 ? "business" : "enterprise";
      const result = await deployDatabase({
        ownerId: user.id,
        name: `admin-${size}mb-db`,
        planSlug: plan
      });

      await interaction.reply({
        content: `Database deployed for ${user.id}.\nPlan: ${plan}\nEndpoint: ${result.database.endpoint}\nAPI Key: ${result.apiKey}`,
        ephemeral: true
      });
      return;
    }

    if (interaction.commandName === "monitor") {
      const overview = await getAdminOverview();
      const embed = new EmbedBuilder()
        .setTitle("System Monitor")
        .setColor(0x63e6be)
        .addFields(
          { name: "Users", value: String(overview.stats.users), inline: true },
          { name: "Admins", value: String(overview.stats.admins), inline: true },
          { name: "Databases", value: String(overview.stats.databases), inline: true },
          { name: "Running", value: String(overview.stats.running), inline: true },
          { name: "Suspended", value: String(overview.stats.suspended), inline: true },
          { name: "Maintenance", value: overview.maintenanceMode ? "true" : "false", inline: true },
          { name: "Blocked IPs", value: String(getBlockedIps().length), inline: true },
          { name: "Action Cooldown", value: `${Math.round(getDashboardCooldownMs() / 1000)}s`, inline: true }
        );

      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    if (interaction.commandName === "suspend") {
      const dbId = interaction.options.getString("db_id", true);
      await changeDatabaseStatus(dbId, DbStatus.SUSPENDED, "Suspended via admin bot command.");
      await interaction.reply({ content: `Database ${dbId} suspended.`, ephemeral: true });
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unexpected bot error.";
    if (interaction.deferred || interaction.replied) {
      await interaction.followUp({ content: message, ephemeral: true });
    } else {
      await interaction.reply({ content: message, ephemeral: true });
    }
  }
});

client.login(token);
