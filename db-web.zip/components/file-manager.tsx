"use client";

import { useState, useTransition } from "react";

type FileKind = "FILE" | "FOLDER";

export function FileManager({
  databaseId,
  files
}: {
  databaseId: string;
  files: Array<{ id: string; path: string; type: FileKind; content: string | null }>;
}) {
  const [path, setPath] = useState("/new.json");
  const [content, setContent] = useState('{\n  "bot": true\n}');
  const [message, setMessage] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function saveFile() {
    startTransition(async () => {
      setMessage(null);
      const response = await fetch(`/api/dashboard/db/${databaseId}/files`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          path,
          type: "FILE",
          content,
          mimeType: "application/json"
        })
      });

      const result = await response.json();
      setMessage(result.message ?? (response.ok ? "File saved." : "File save failed."));
      if (response.ok) {
        window.location.reload();
      }
    });
  }

  async function deleteFile(targetPath: string) {
    const response = await fetch(`/api/dashboard/db/${databaseId}/files?path=${encodeURIComponent(targetPath)}`, {
      method: "DELETE"
    });

    const result = await response.json();
    setMessage(result.message ?? (response.ok ? "File deleted." : "Delete failed."));
    if (response.ok) {
      window.location.reload();
    }
  }

  return (
    <section className="card manager-card">
      <div className="section-head">
        <div>
          <p className="eyebrow">File Manager</p>
          <h3>Read / change file access</h3>
        </div>
      </div>

      <div className="field-grid">
        <label className="field">
          <span>Path</span>
          <input value={path} onChange={(event) => setPath(event.target.value)} />
        </label>
        <label className="field">
          <span>Type</span>
          <input value="FILE" disabled />
        </label>
      </div>

      <label className="field">
        <span>Content</span>
        <textarea rows={8} value={content} onChange={(event) => setContent(event.target.value)} />
      </label>

      <button className="button button-primary" disabled={isPending} onClick={saveFile} type="button">
        Save File
      </button>

      {message ? <p className="hint">{message}</p> : null}

      <div className="table-shell">
        <table>
          <thead>
            <tr>
              <th>Path</th>
              <th>Type</th>
              <th>Preview</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {files.map((file) => (
              <tr key={file.id}>
                <td>{file.path}</td>
                <td>{file.type}</td>
                <td>{file.content?.slice(0, 40) ?? "-"}</td>
                <td>
                  <button className="button subtle-button" onClick={() => deleteFile(file.path)} type="button">
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
