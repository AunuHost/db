"use client";

import { signIn } from "next-auth/react";

export function LoginButton() {
  return (
    <button className="button button-primary" onClick={() => signIn("discord", { callbackUrl: "/dashboard" })} type="button">
      Login with Discord
    </button>
  );
}
