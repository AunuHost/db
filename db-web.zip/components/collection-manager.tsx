"use client";

import { useState, useTransition } from "react";

export function CollectionManager({
  databaseId,
  initialCollection = "profiles"
}: {
  databaseId: string;
  initialCollection?: string;
}) {
  const [collection, setCollection] = useState(initialCollection);
  const [payload, setPayload] = useState('{\n  "hello": "world"\n}');
  const [message, setMessage] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function handleCreate() {
    startTransition(async () => {
      setMessage(null);
      let parsedPayload: Record<string, unknown>;

      try {
        parsedPayload = JSON.parse(payload) as Record<string, unknown>;
      } catch {
        setMessage("Invalid JSON payload.");
        return;
      }

      const response = await fetch(`/api/dashboard/db/${databaseId}/collections`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          collection,
          data: parsedPayload
        })
      });

      const result = await response.json();
      setMessage(result.message ?? (response.ok ? "Document saved." : "Document failed."));
      if (response.ok) {
        window.location.reload();
      }
    });
  }

  return (
    <section className="card manager-card">
      <div className="section-head">
        <div>
          <p className="eyebrow">Collection Manager</p>
          <h3>Create or update a document</h3>
        </div>
      </div>

      <label className="field">
        <span>Collection</span>
        <input value={collection} onChange={(event) => setCollection(event.target.value)} />
      </label>

      <label className="field">
        <span>JSON Payload</span>
        <textarea rows={10} value={payload} onChange={(event) => setPayload(event.target.value)} />
      </label>

      <button className="button button-primary" disabled={isPending} onClick={handleCreate} type="button">
        Save Document
      </button>

      {message ? <p className="hint">{message}</p> : null}
    </section>
  );
}
