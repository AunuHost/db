import Link from "next/link";
import { getCurrentSession } from "@/lib/session";
import { FOOTER_COPY } from "@/lib/constants";
import { getInviteUrl } from "@/lib/env";
import { SignOutButton } from "./sign-out-button";

export async function AppShell({ children }: { children: React.ReactNode }) {
  const session = await getCurrentSession();

  return (
    <div className="site-shell">
      <header className="topbar">
        <div className="container topbar-inner">
          <Link href="/" className="brand">
            <span className="brand-mark">LD</span>
            <span>
              Loudness DB
              <small>Deploy once. Monitor deeply.</small>
            </span>
          </Link>

          <nav className="nav">
            <Link href="/docs">Docs</Link>
            <Link href="/status">Status</Link>
            {session?.user?.id ? <Link href="/dashboard">Dashboard</Link> : null}
            {session?.user?.role === "ADMIN" || session?.user?.role === "OWNER" ? <Link href="/admin">Admin</Link> : null}
            <a href={getInviteUrl()} target="_blank" rel="noreferrer">
              Discord
            </a>
            {session?.user?.id ? (
              <SignOutButton />
            ) : (
              <Link href="/login" className="button subtle-button">
                Login
              </Link>
            )}
          </nav>
        </div>
      </header>

      <main>{children}</main>

      <footer className="footer">
        <div className="container footer-grid">
          <div>
            <h3>Loudness DB</h3>
            <p>Database platform with Discord auth, private API keys, user and admin dashboards, and Discord bot controls.</p>
          </div>
          <div>
            <h4>Pages</h4>
            <Link href="/">Home</Link>
            <Link href="/docs">Docs</Link>
            <Link href="/status">Status</Link>
          </div>
          <div>
            <h4>Identity</h4>
            <span>{FOOTER_COPY}</span>
            <span>Public URL: {process.env.NEXT_PUBLIC_APP_URL ?? "https://db.aerodynamic.biz.id"}</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
