"use client";

import { useState, useTransition } from "react";

export function AdminPlanForm() {
  const [form, setForm] = useState({
    name: "",
    slug: "",
    description: "",
    priceMonthly: "19",
    storageLimitMb: "1024",
    deployLimit: "1",
    apiRateLimit: "300",
    features: "Dedicated API key, Dashboard analytics, File manager"
  });
  const [message, setMessage] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function updateField(key: keyof typeof form, value: string) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function submit() {
    startTransition(async () => {
      const response = await fetch("/api/admin/plans", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          priceMonthly: Number(form.priceMonthly),
          storageLimitMb: Number(form.storageLimitMb),
          deployLimit: Number(form.deployLimit),
          apiRateLimit: Number(form.apiRateLimit),
          features: form.features.split(",").map((item) => item.trim()).filter(Boolean)
        })
      });

      const result = await response.json();
      setMessage(result.message ?? (response.ok ? "Plan created." : "Plan create failed."));
      if (response.ok) {
        window.location.reload();
      }
    });
  }

  return (
    <section className="card manager-card">
      <div className="section-head">
        <div>
          <p className="eyebrow">Plan Builder</p>
          <h3>Create a new plan</h3>
        </div>
      </div>

      <div className="field-grid two-up">
        <label className="field">
          <span>Name</span>
          <input value={form.name} onChange={(event) => updateField("name", event.target.value)} />
        </label>
        <label className="field">
          <span>Slug</span>
          <input value={form.slug} onChange={(event) => updateField("slug", event.target.value)} />
        </label>
        <label className="field">
          <span>Price Monthly</span>
          <input value={form.priceMonthly} onChange={(event) => updateField("priceMonthly", event.target.value)} />
        </label>
        <label className="field">
          <span>Storage MB</span>
          <input value={form.storageLimitMb} onChange={(event) => updateField("storageLimitMb", event.target.value)} />
        </label>
        <label className="field">
          <span>Deploy Limit</span>
          <input value={form.deployLimit} onChange={(event) => updateField("deployLimit", event.target.value)} />
        </label>
        <label className="field">
          <span>API Rate Limit</span>
          <input value={form.apiRateLimit} onChange={(event) => updateField("apiRateLimit", event.target.value)} />
        </label>
      </div>

      <label className="field">
        <span>Description</span>
        <textarea rows={3} value={form.description} onChange={(event) => updateField("description", event.target.value)} />
      </label>

      <label className="field">
        <span>Features (comma separated)</span>
        <textarea rows={3} value={form.features} onChange={(event) => updateField("features", event.target.value)} />
      </label>

      <button className="button button-primary" disabled={isPending} onClick={submit} type="button">
        Save Plan
      </button>

      {message ? <p className="hint">{message}</p> : null}
    </section>
  );
}
