"use client";

import { signOut } from "next-auth/react";

export function SignOutButton() {
  return (
    <button className="button subtle-button" onClick={() => signOut({ callbackUrl: "/" })} type="button">
      Logout
    </button>
  );
}
