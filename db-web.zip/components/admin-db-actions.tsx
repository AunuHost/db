"use client";

import { useState, useTransition } from "react";

export function AdminDbActions({ dbId }: { dbId: string }) {
  const [message, setMessage] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  async function handleAction(action: string) {
    startTransition(async () => {
      const response = await fetch(`/api/admin/db/${dbId}/${action}`, {
        method: "POST"
      });
      const result = await response.json();
      setMessage(result.message ?? (response.ok ? "Done." : "Failed."));
      if (response.ok && action !== "redeploy" && action !== "regenerate-key") {
        window.location.reload();
      }
    });
  }

  return (
    <div className="action-stack">
      <div className="inline-actions">
        <button className="button subtle-button" disabled={isPending} onClick={() => handleAction("start")} type="button">
          Start
        </button>
        <button className="button subtle-button" disabled={isPending} onClick={() => handleAction("stop")} type="button">
          Stop
        </button>
        <button className="button subtle-button" disabled={isPending} onClick={() => handleAction("restart")} type="button">
          Restart
        </button>
        <button className="button subtle-button" disabled={isPending} onClick={() => handleAction("redeploy")} type="button">
          Redeploy
        </button>
        <button className="button subtle-button" disabled={isPending} onClick={() => handleAction("regenerate-key")} type="button">
          Regenerate API Key
        </button>
        <button className="button subtle-button" disabled={isPending} onClick={() => handleAction("suspend")} type="button">
          Suspend
        </button>
      </div>
      {message ? <p className="hint">{message}</p> : null}
    </div>
  );
}
