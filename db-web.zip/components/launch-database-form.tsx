"use client";

import { useState, useTransition } from "react";

export function LaunchDatabaseForm({ defaultPlan = "starter" }: { defaultPlan?: string }) {
  const [name, setName] = useState("My Primary DB");
  const [planSlug, setPlanSlug] = useState(defaultPlan);
  const [message, setMessage] = useState<string | null>(null);
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function submit() {
    startTransition(async () => {
      const response = await fetch("/api/dashboard/deploy", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          name,
          planSlug
        })
      });

      const result = await response.json();
      setMessage(result.message ?? (response.ok ? "Database deployed." : "Deploy failed."));
      setApiKey(result.apiKey ?? null);
    });
  }

  return (
    <section className="card manager-card">
      <div className="section-head">
        <div>
          <p className="eyebrow">Deploy Database</p>
          <h3>Create a new logical database</h3>
        </div>
      </div>

      <label className="field">
        <span>Database Name</span>
        <input value={name} onChange={(event) => setName(event.target.value)} />
      </label>

      <label className="field">
        <span>Plan</span>
        <select value={planSlug} onChange={(event) => setPlanSlug(event.target.value)}>
          <option value="starter">Starter</option>
          <option value="business">Business</option>
          <option value="enterprise">Enterprise</option>
        </select>
      </label>

      <button className="button button-primary" disabled={isPending} onClick={submit} type="button">
        Deploy Now
      </button>

      {message ? <p className="hint">{message}</p> : null}
      {apiKey ? <code className="inline-code-box">{apiKey}</code> : null}
    </section>
  );
}
