"use client";

import { useState, useTransition } from "react";

type ActionName = "start" | "stop" | "restart" | "redeploy";
type ExtendedActionName = ActionName | "regenerate-key";

export function DatabaseActions({ dbId }: { dbId: string }) {
  const [message, setMessage] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function runAction(action: ExtendedActionName) {
    startTransition(async () => {
      setMessage(null);

      const response = await fetch(`/api/dashboard/db/${dbId}/${action}`, {
        method: "POST"
      });

      const payload = await response.json();
      setMessage(payload.message ?? (response.ok ? "Action completed." : "Action failed."));

      if (response.ok && action !== "redeploy" && action !== "regenerate-key") {
        window.location.reload();
      }
    });
  }

  return (
    <div className="action-stack">
      <div className="inline-actions">
        <button className="button button-primary" disabled={isPending} onClick={() => runAction("start")} type="button">
          Start
        </button>
        <button className="button subtle-button" disabled={isPending} onClick={() => runAction("stop")} type="button">
          Stop
        </button>
        <button className="button subtle-button" disabled={isPending} onClick={() => runAction("restart")} type="button">
          Restart
        </button>
        <button className="button subtle-button" disabled={isPending} onClick={() => runAction("redeploy")} type="button">
          Redeploy
        </button>
        <button className="button subtle-button" disabled={isPending} onClick={() => runAction("regenerate-key")} type="button">
          Regenerate API Key
        </button>
      </div>
      {message ? <p className="hint">{message}</p> : null}
    </div>
  );
}
