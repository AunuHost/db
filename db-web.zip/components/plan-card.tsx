import { Plan } from "@prisma/client";
import { formatCurrency, safeJsonParse } from "@/lib/utils";

export function PlanCard({ plan }: { plan: Plan }) {
  const features = safeJsonParse<string[]>(plan.features, []);

  return (
    <article className="card plan-card">
      <div className="plan-head">
        <div>
          <p className="eyebrow">{plan.slug}</p>
          <h3>{plan.name}</h3>
        </div>
        <strong>{formatCurrency(plan.priceMonthly)}</strong>
      </div>
      <p>{plan.description}</p>
      <div className="plan-meta">
        <span>{plan.storageLimitMb >= 1024 ? `${plan.storageLimitMb / 1024} GB` : `${plan.storageLimitMb} MB`}</span>
        <span>{plan.deployLimit} active deployment</span>
        <span>{plan.apiRateLimit} req/min</span>
      </div>
      <ul className="feature-list">
        {features.map((feature) => (
          <li key={feature}>{feature}</li>
        ))}
      </ul>
    </article>
  );
}
