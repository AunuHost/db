import { createHash, randomBytes } from "crypto";

export function createApiKey() {
  const raw = `ldb_${randomBytes(24).toString("hex")}`;

  return {
    raw,
    hash: hashApiKey(raw),
    preview: `${raw.slice(0, 7)}...${raw.slice(-4)}`
  };
}

export function hashApiKey(raw: string) {
  return createHash("sha256").update(raw).digest("hex");
}

export function verifyApiKey(raw: string, hash: string) {
  return hashApiKey(raw) === hash;
}
