import { DbStatus, FileType, Prisma, UserRole } from "@prisma/client";
import { z } from "zod";
import { createApiKey, verifyApiKey } from "./api-key";
import { getAppUrl } from "./env";
import { prisma } from "./prisma";
import { assertPayloadBytes, getDocumentLimitBytes, getFileLimitBytes, normalizeFilePath, validateCollectionName } from "./security";
import { safeJsonParse, slugify } from "./utils";

const createDatabaseSchema = z.object({
  ownerId: z.string(),
  name: z.string().min(2).max(48),
  planSlug: z.string().default("starter")
});

const filePayloadSchema = z.object({
  path: z.string().min(1),
  type: z.nativeEnum(FileType),
  content: z.string().optional(),
  mimeType: z.string().optional()
});

function createPublicId() {
  return `db_${Math.random().toString(36).slice(2, 10)}`;
}

async function syncDatabaseStorage(dbId: string) {
  const [documents, files] = await Promise.all([
    prisma.document.findMany({
      where: {
        collection: { dbId }
      },
      select: { byteSize: true }
    }),
    prisma.fileEntry.findMany({
      where: { dbId },
      select: { size: true }
    })
  ]);

  const totalBytes =
    documents.reduce((sum, document) => sum + document.byteSize, 0) +
    files.reduce((sum, file) => sum + file.size, 0);

  return prisma.dbInstance.update({
    where: { id: dbId },
    data: {
      usedStorageMb: totalBytes / (1024 * 1024)
    }
  });
}

function assertStorageAllowance(currentMb: number, limitMb: number, additionalBytes: number) {
  const projectedMb = currentMb + additionalBytes / (1024 * 1024);
  if (projectedMb > limitMb) {
    throw new Error(`Storage limit exceeded. Projected usage ${projectedMb.toFixed(2)} MB of ${limitMb} MB.`);
  }
}

export async function ensureStarterData(ownerId: string, databaseId: string) {
  const collection = await prisma.collection.upsert({
    where: {
      dbId_slug: {
        dbId: databaseId,
        slug: "profiles"
      }
    },
    update: {},
    create: {
      dbId: databaseId,
      name: "Profiles",
      slug: "profiles"
    }
  });

  const count = await prisma.document.count({
    where: { collectionId: collection.id }
  });

  if (count === 0) {
    const payload = JSON.stringify({
      userId: ownerId,
      nickname: "New User",
      badges: ["discord", "db"],
      createdVia: "seed"
    });

    await prisma.document.create({
      data: {
        collectionId: collection.id,
        ownerId,
        data: payload,
        byteSize: Buffer.byteLength(payload, "utf8")
      }
    });
  }

  await prisma.fileEntry.upsert({
    where: {
      dbId_path: {
        dbId: databaseId,
        path: "/README.md"
      }
    },
    update: {},
    create: {
      dbId: databaseId,
      path: "/README.md",
      name: "README.md",
      type: FileType.FILE,
      content: "# Loudness DB\nLogical database instance with API key access.",
      mimeType: "text/markdown",
      size: 58,
      updatedById: ownerId
    }
  });
}

export async function deployDatabase(input: z.input<typeof createDatabaseSchema>) {
  const parsed = createDatabaseSchema.parse(input);
  const plan = await prisma.plan.findUnique({
    where: { slug: parsed.planSlug }
  });

  if (!plan) {
    throw new Error("Plan not found.");
  }

  const existing = await prisma.dbInstance.count({
    where: {
      ownerId: parsed.ownerId,
      status: {
        not: DbStatus.FAILED
      }
    }
  });

  if (existing >= plan.deployLimit) {
    throw new Error("Deploy limit reached for this plan.");
  }

  const apiKey = createApiKey();
  const slug = slugify(parsed.name);
  const publicId = createPublicId();
  const endpoint = `${getAppUrl()}/api/v1/db/${publicId}`;

  const database = await prisma.dbInstance.create({
    data: {
      publicId,
      name: parsed.name,
      slug,
      endpoint,
      ownerId: parsed.ownerId,
      planId: plan.id,
      status: DbStatus.RUNNING,
      region: process.env.DEFAULT_REGION ?? "Singapore",
      storageLimitMb: plan.storageLimitMb,
      usedStorageMb: 0,
      apiKeyHash: apiKey.hash,
      apiKeyPreview: apiKey.preview,
      deploymentCount: 1,
      lastDeployAt: new Date(),
      deployedAt: new Date()
    },
    include: {
      plan: true,
      owner: true
    }
  });

  await ensureStarterData(parsed.ownerId, database.id);
  await captureUsageSnapshot(database.id);

  return {
    database,
    apiKey: apiKey.raw
  };
}

export async function changeDatabaseStatus(dbId: string, status: DbStatus, maintenanceNote?: string | null) {
  const database = await prisma.dbInstance.update({
    where: { id: dbId },
    data: {
      status,
      maintenanceNote: maintenanceNote ?? null,
      stoppedAt: status === DbStatus.STOPPED ? new Date() : null,
      suspendedAt: status === DbStatus.SUSPENDED ? new Date() : null
    }
  });

  await captureUsageSnapshot(dbId);
  return database;
}

export async function restartDatabase(dbId: string) {
  await prisma.dbInstance.update({
    where: { id: dbId },
    data: {
      status: DbStatus.RESTARTING
    }
  });

  const database = await prisma.dbInstance.update({
    where: { id: dbId },
    data: {
      status: DbStatus.RUNNING,
      stoppedAt: null
    }
  });

  await captureUsageSnapshot(dbId);
  return database;
}

export async function redeployDatabase(dbId: string) {
  const apiKey = createApiKey();
  const database = await prisma.dbInstance.update({
    where: { id: dbId },
    data: {
      status: DbStatus.RUNNING,
      apiKeyHash: apiKey.hash,
      apiKeyPreview: apiKey.preview,
      deploymentCount: {
        increment: 1
      },
      lastDeployAt: new Date(),
      deployedAt: new Date(),
      maintenanceNote: null
    }
  });

  await captureUsageSnapshot(dbId);

  return {
    database,
    apiKey: apiKey.raw
  };
}

export async function captureUsageSnapshot(dbId: string) {
  const [collections, documents, files, database, requestCount] = await Promise.all([
    prisma.collection.count({ where: { dbId } }),
    prisma.document.count({
      where: {
        collection: { dbId }
      }
    }),
    prisma.fileEntry.count({ where: { dbId } }),
    prisma.dbInstance.findUniqueOrThrow({ where: { id: dbId } }),
    prisma.apiAuditLog.count({ where: { dbId } })
  ]);

  return prisma.usageSnapshot.create({
    data: {
      dbId,
      storageUsedMb: database.usedStorageMb,
      documentCount: documents,
      collectionCount: collections,
      fileCount: files,
      requestCount,
      uptimePercent: database.status === DbStatus.RUNNING ? 99.95 : 95.12
    }
  });
}

export async function getDatabaseStats(dbId: string) {
  const database = await prisma.dbInstance.findUniqueOrThrow({
    where: { id: dbId },
    include: {
      plan: true,
      owner: true,
      collections: {
        include: {
          documents: true
        }
      },
      files: true,
      apiLogs: {
        orderBy: { createdAt: "desc" },
        take: 20
      },
      usageSnapshots: {
        orderBy: { createdAt: "desc" },
        take: 8
      }
    }
  });

  return {
    database,
    totalCollections: database.collections.length,
    totalDocuments: database.collections.reduce((acc, collection) => acc + collection.documents.length, 0),
    totalFiles: database.files.length,
    recentRequests: database.apiLogs.length,
    latestSnapshot: database.usageSnapshots[0] ?? null
  };
}

export async function upsertCollectionDocument(params: {
  dbPublicId: string;
  collectionName: string;
  data: Prisma.JsonObject;
  ownerId: string;
  documentId?: string;
}) {
  const database = await prisma.dbInstance.findUniqueOrThrow({
    where: { publicId: params.dbPublicId }
  });
  const collectionName = validateCollectionName(params.collectionName);

  const collection = await prisma.collection.upsert({
    where: {
      dbId_slug: {
        dbId: database.id,
        slug: slugify(collectionName)
      }
    },
    update: {
      name: collectionName
    },
    create: {
      dbId: database.id,
      name: collectionName,
      slug: slugify(collectionName)
    }
  });

  const serialized = JSON.stringify(params.data);
  const byteSize = assertPayloadBytes(serialized, getDocumentLimitBytes(), "Document payload");
  const existingDocument = params.documentId
    ? await prisma.document.findUnique({
        where: { id: params.documentId },
        select: { byteSize: true }
      })
    : null;
  const additionalBytes = Math.max(0, byteSize - (existingDocument?.byteSize ?? 0));
  assertStorageAllowance(database.usedStorageMb, database.storageLimitMb, additionalBytes);
  const document = params.documentId
    ? await prisma.document.update({
        where: { id: params.documentId },
        data: {
          data: serialized,
          byteSize,
          version: {
            increment: 1
          }
        }
      })
    : await prisma.document.create({
        data: {
          collectionId: collection.id,
          ownerId: params.ownerId,
          data: serialized,
          byteSize
        }
      });

  await syncDatabaseStorage(database.id);
  await captureUsageSnapshot(database.id);
  return document;
}

export async function listCollectionDocuments(dbPublicId: string, collectionName: string) {
  const database = await prisma.dbInstance.findUniqueOrThrow({
    where: { publicId: dbPublicId }
  });

  const collection = await prisma.collection.findUnique({
    where: {
      dbId_slug: {
        dbId: database.id,
        slug: slugify(collectionName)
      }
    },
    include: {
      documents: {
        orderBy: { updatedAt: "desc" }
      }
    }
  });

  return (collection?.documents ?? []).map((document) => ({
    ...document,
    data: safeJsonParse(document.data, {})
  }));
}

export async function deleteCollectionDocument(documentId: string) {
  const document = await prisma.document.delete({
    where: { id: documentId },
    include: {
      collection: true
    }
  });

  await syncDatabaseStorage(document.collection.dbId);
  await captureUsageSnapshot(document.collection.dbId);
  return document;
}

export async function upsertFileEntry(dbId: string, userId: string, input: z.input<typeof filePayloadSchema>) {
  const parsed = filePayloadSchema.parse(input);
  const database = await prisma.dbInstance.findUniqueOrThrow({
    where: { id: dbId }
  });
  const normalizedPath = normalizeFilePath(parsed.path);
  const name = normalizedPath.split("/").filter(Boolean).pop() ?? "/";
  const content = parsed.type === FileType.FILE ? parsed.content ?? "" : null;
  const size = content ? assertPayloadBytes(content, getFileLimitBytes(), "File content") : 0;
  const existingEntry = await prisma.fileEntry.findUnique({
    where: {
      dbId_path: {
        dbId,
        path: normalizedPath
      }
    },
    select: { size: true }
  });
  const additionalBytes = Math.max(0, size - (existingEntry?.size ?? 0));
  assertStorageAllowance(database.usedStorageMb, database.storageLimitMb, additionalBytes);

  const entry = await prisma.fileEntry.upsert({
    where: {
      dbId_path: {
        dbId,
        path: normalizedPath
      }
    },
    update: {
      name,
      type: parsed.type,
      content,
      mimeType: parsed.mimeType,
      size,
      updatedById: userId
    },
    create: {
      dbId,
      path: normalizedPath,
      name,
      type: parsed.type,
      content,
      mimeType: parsed.mimeType,
      size,
      updatedById: userId
    }
  });

  await syncDatabaseStorage(dbId);
  await captureUsageSnapshot(dbId);
  return entry;
}

export async function deleteFileEntry(dbId: string, path: string) {
  const normalizedPath = normalizeFilePath(path);
  const entry = await prisma.fileEntry.delete({
    where: {
      dbId_path: {
        dbId,
        path: normalizedPath
      }
    }
  });

  await syncDatabaseStorage(dbId);
  await captureUsageSnapshot(dbId);
  return entry;
}

export async function logApiEvent(input: {
  dbId: string;
  userId?: string | null;
  action: string;
  route: string;
  statusCode: number;
  metadata?: unknown;
  ipAddress?: string | null;
  userAgent?: string | null;
}) {
  return prisma.apiAuditLog.create({
    data: {
      dbId: input.dbId,
      userId: input.userId ?? null,
      action: input.action,
      route: input.route,
      statusCode: input.statusCode,
      metadata: input.metadata ? JSON.stringify(input.metadata) : null,
      ipAddress: input.ipAddress,
      userAgent: input.userAgent
    }
  });
}

export async function verifyDatabaseApiKey(dbPublicId: string, apiKey: string) {
  const database = await prisma.dbInstance.findUnique({
    where: { publicId: dbPublicId },
    include: {
      plan: true
    }
  });

  if (!database) {
    return null;
  }

  return verifyApiKey(apiKey, database.apiKeyHash) ? database : null;
}

export async function listDatabaseCollections(dbPublicId: string) {
  const database = await prisma.dbInstance.findUniqueOrThrow({
    where: { publicId: dbPublicId }
  });

  return prisma.collection.findMany({
    where: { dbId: database.id },
    include: {
      _count: {
        select: {
          documents: true
        }
      }
    },
    orderBy: { updatedAt: "desc" }
  });
}

export async function searchDatabaseDocuments(dbPublicId: string, term: string, limit = 20) {
  const database = await prisma.dbInstance.findUniqueOrThrow({
    where: { publicId: dbPublicId }
  });

  const documents = await prisma.document.findMany({
    where: {
      collection: { dbId: database.id }
    },
    include: {
      collection: true
    },
    orderBy: { updatedAt: "desc" },
    take: Math.min(Math.max(limit, 1), 50)
  });

  const lowered = term.toLowerCase();
  return documents
    .filter((document) => document.data.toLowerCase().includes(lowered))
    .map((document) => ({
      id: document.id,
      collection: document.collection.name,
      updatedAt: document.updatedAt,
      data: safeJsonParse(document.data, {})
    }));
}

export async function exportDatabaseBundle(dbPublicId: string) {
  const database = await prisma.dbInstance.findUniqueOrThrow({
    where: { publicId: dbPublicId },
    include: {
      plan: true,
      collections: {
        include: {
          documents: true
        }
      },
      files: true,
      usageSnapshots: {
        orderBy: { createdAt: "desc" },
        take: 12
      }
    }
  });

  return {
    database: {
      publicId: database.publicId,
      name: database.name,
      status: database.status,
      endpoint: database.endpoint,
      region: database.region,
      storageLimitMb: database.storageLimitMb,
      usedStorageMb: database.usedStorageMb,
      plan: database.plan.name
    },
    collections: database.collections.map((collection) => ({
      name: collection.name,
      slug: collection.slug,
      documents: collection.documents.map((document) => ({
        id: document.id,
        version: document.version,
        updatedAt: document.updatedAt,
        data: safeJsonParse(document.data, {})
      }))
    })),
    files: database.files.map((file) => ({
      path: file.path,
      type: file.type,
      mimeType: file.mimeType,
      size: file.size,
      content: file.content
    })),
    snapshots: database.usageSnapshots
  };
}

export async function getPublicDatabaseStats(dbPublicId: string) {
  const database = await prisma.dbInstance.findUniqueOrThrow({
    where: { publicId: dbPublicId },
    include: {
      plan: true,
      usageSnapshots: {
        orderBy: { createdAt: "desc" },
        take: 10
      },
      collections: true,
      files: true
    }
  });

  const documentCount = await prisma.document.count({
    where: {
      collection: { dbId: database.id }
    }
  });

  return {
    publicId: database.publicId,
    name: database.name,
    status: database.status,
    region: database.region,
    plan: database.plan.name,
    storageLimitMb: database.storageLimitMb,
    usedStorageMb: database.usedStorageMb,
    deploymentCount: database.deploymentCount,
    collections: database.collections.length,
    documents: documentCount,
    files: database.files.length,
    snapshots: database.usageSnapshots
  };
}

export async function getAdminOverview() {
  const [users, databases, plans, maintenance] = await Promise.all([
    prisma.user.findMany({
      orderBy: { createdAt: "desc" },
      include: {
        plan: true,
        databases: true
      }
    }),
    prisma.dbInstance.findMany({
      orderBy: { createdAt: "desc" },
      include: {
        owner: true,
        plan: true,
        usageSnapshots: {
          orderBy: { createdAt: "desc" },
          take: 1
        }
      }
    }),
    prisma.plan.findMany({
      orderBy: { priceMonthly: "asc" }
    }),
    prisma.systemSetting.findUnique({
      where: { key: "maintenance_mode" }
    })
  ]);

  return {
    users,
    databases,
    plans,
    maintenanceMode: maintenance?.value === "true",
    stats: {
      users: users.length,
      admins: users.filter((user) => user.role === UserRole.ADMIN || user.role === UserRole.OWNER).length,
      databases: databases.length,
      running: databases.filter((db) => db.status === DbStatus.RUNNING).length,
      suspended: databases.filter((db) => db.status === DbStatus.SUSPENDED).length
    }
  };
}

export async function setMaintenanceMode(value: boolean) {
  return prisma.systemSetting.upsert({
    where: { key: "maintenance_mode" },
    update: { value: String(value) },
    create: {
      key: "maintenance_mode",
      value: String(value)
    }
  });
}

export async function setUserRole(userId: string, role: UserRole) {
  return prisma.user.update({
    where: { id: userId },
    data: { role }
  });
}

export async function createPlan(input: {
  name: string;
  slug: string;
  description: string;
  priceMonthly: number;
  storageLimitMb: number;
  deployLimit: number;
  apiRateLimit: number;
  features: string[];
}) {
  return prisma.plan.create({
    data: {
      ...input,
      features: JSON.stringify(input.features)
    }
  });
}
