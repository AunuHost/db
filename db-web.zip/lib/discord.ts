import { getInviteUrl } from "./env";

export async function ensureDiscordGuildJoin(params: {
  discordUserId: string;
  accessToken?: string | null;
}) {
  const guildId = process.env.DISCORD_GUILD_ID;
  const botToken = process.env.DISCORD_BOT_TOKEN;

  if (!guildId || !botToken || !params.accessToken) {
    return {
      joined: false,
      reason: "missing-config",
      fallbackInvite: getInviteUrl()
    };
  }

  try {
    const response = await fetch(`https://discord.com/api/guilds/${guildId}/members/${params.discordUserId}`, {
      method: "PUT",
      headers: {
        Authorization: `Bot ${botToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        access_token: params.accessToken
      })
    });

    return {
      joined: response.ok,
      reason: response.ok ? "joined" : `discord-${response.status}`,
      fallbackInvite: getInviteUrl()
    };
  } catch {
    return {
      joined: false,
      reason: "request-failed",
      fallbackInvite: getInviteUrl()
    };
  }
}
