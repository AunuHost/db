import { NextRequest } from "next/server";
import { verifyDatabaseApiKey } from "./db-service";
import {
  applyRateLimitHeaders,
  assertApiKeyShape,
  assertIpAllowed,
  assertPublicDatabaseReady,
  getClientIp,
  getPublicApiWindowMs,
  isMaintenanceMode,
  jsonError,
  rateLimit
} from "./security";

export async function authorizePublicApiRequest(request: NextRequest, dbPublicId: string) {
  try {
    const apiKey = assertApiKeyShape(request.headers.get("x-api-key"));
    const ip = getClientIp(request);
    assertIpAllowed(ip);

    const database = await verifyDatabaseApiKey(dbPublicId, apiKey);
    if (!database) {
      return {
        ok: false as const,
        response: jsonError("Unauthorized.", 401)
      };
    }

    const maintenanceMode = await isMaintenanceMode();
    assertPublicDatabaseReady(database, maintenanceMode);

    const result = rateLimit(
      `public:${database.publicId}:${ip}`,
      database.plan?.apiRateLimit ?? 120,
      getPublicApiWindowMs()
    );

    if (!result.allowed) {
      return {
        ok: false as const,
        response: jsonError("Too many requests. Anti-flood protection triggered.", 429, result)
      };
    }

    return {
      ok: true as const,
      database,
      ip,
      rateLimit: result
    };
  } catch (error) {
    return {
      ok: false as const,
      response: jsonError(error instanceof Error ? error.message : "Unauthorized.", 403)
    };
  }
}

export { applyRateLimitHeaders };
