import { UserRole } from "@prisma/client";
import type { NextAuthOptions } from "next-auth";
import NextAuth from "next-auth";
import DiscordProvider from "next-auth/providers/discord";
import { ensureDiscordGuildJoin } from "./discord";
import { prisma } from "./prisma";

export const authOptions: NextAuthOptions = {
  session: {
    strategy: "jwt"
  },
  pages: {
    signIn: "/login"
  },
  providers: [
    DiscordProvider({
      clientId: process.env.DISCORD_CLIENT_ID ?? "",
      clientSecret: process.env.DISCORD_CLIENT_SECRET ?? "",
      authorization: {
        params: {
          scope: "identify email guilds guilds.join"
        }
      },
      profile(profile) {
        return {
          id: profile.id,
          name: profile.global_name ?? profile.username,
          email: profile.email,
          image: profile.avatar
            ? `https://cdn.discordapp.com/avatars/${profile.id}/${profile.avatar}.png`
            : null,
          username: profile.username,
          globalName: profile.global_name
        };
      }
    })
  ],
  callbacks: {
    async signIn({ user, account, profile }) {
      const profileData = profile as { id?: string; username?: string; global_name?: string } | undefined;
      const discordId = profileData?.id ?? account?.providerAccountId;

      if (!discordId) {
        return false;
      }

      const existingPlans = await prisma.plan.findMany({
        orderBy: { priceMonthly: "asc" }
      });

      const defaultPlan = existingPlans.find((plan) => plan.slug === "starter") ?? existingPlans[0];

      const currentUser = await prisma.user.upsert({
        where: { discordId },
        update: {
          username: profileData?.username ?? user.name ?? "discord-user",
          globalName: profileData?.global_name ?? user.name ?? null,
          email: user.email,
          image: user.image,
          lastLoginAt: new Date()
        },
        create: {
          discordId,
          username: profileData?.username ?? user.name ?? "discord-user",
          globalName: profileData?.global_name ?? user.name ?? null,
          email: user.email,
          image: user.image,
          lastLoginAt: new Date(),
          role: discordId === process.env.DISCORD_OWNER_ID ? UserRole.OWNER : UserRole.USER,
          planId: defaultPlan?.id
        }
      });

      user.id = currentUser.id;
      user.username = currentUser.username;
      user.globalName = currentUser.globalName;

      await ensureDiscordGuildJoin({
        discordUserId: discordId,
        accessToken: account?.access_token
      });

      return true;
    },
    async jwt({ token, user, profile }) {
      const discordId = (profile as { id?: string } | undefined)?.id ?? user?.id;
      const filters: Array<{ id?: string; discordId?: string }> = [];

      if (user?.id) {
        filters.push({ id: user.id });
      }

      if (discordId) {
        filters.push({ discordId });
      }

      if (filters.length > 0) {
        const currentUser = await prisma.user.findFirst({
          where: {
            OR: filters
          }
        });

        if (currentUser) {
          token.id = currentUser.id;
          token.role = currentUser.role;
          token.discordId = currentUser.discordId;
        }
      }

      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = (token.id as string) ?? "";
        session.user.role = (token.role as UserRole) ?? UserRole.USER;
        session.user.discordId = (token.discordId as string) ?? "";
      }

      return session;
    }
  }
};

export default NextAuth(authOptions);
