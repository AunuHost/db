const required = [
  "DATABASE_URL",
  "NEXTAUTH_SECRET",
  "DISCORD_CLIENT_ID",
  "DISCORD_CLIENT_SECRET"
] as const;

export function validateEnv() {
  const missing = required.filter((key) => !process.env[key]);
  return {
    valid: missing.length === 0,
    missing
  };
}

export function getAppUrl() {
  return process.env.NEXT_PUBLIC_APP_URL ?? "https://db.aerodynamic.biz.id";
}

export function getInviteUrl() {
  return process.env.DISCORD_INVITE_URL ?? "https://discord.gg/QvWfzk9PME";
}
