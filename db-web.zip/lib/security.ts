import { DbInstance, DbStatus, Plan, Prisma } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "./prisma";

type RateLimitState = {
  count: number;
  resetAt: number;
};

type RateLimitResult = {
  allowed: boolean;
  limit: number;
  remaining: number;
  resetAt: number;
  retryAfter: number;
};

const rateLimitStore = new Map<string, RateLimitState>();
const cooldownStore = new Map<string, number>();

function getNow() {
  return Date.now();
}

export function getClientIp(request: NextRequest) {
  return (
    request.headers.get("cf-connecting-ip") ??
    request.headers.get("x-real-ip") ??
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    "0.0.0.0"
  );
}

export function getRequestFingerprint(request: NextRequest) {
  return `${getClientIp(request)}:${request.headers.get("user-agent") ?? "unknown"}`;
}

export function rateLimit(key: string, limit: number, windowMs: number): RateLimitResult {
  const now = getNow();
  const current = rateLimitStore.get(key);

  if (!current || current.resetAt <= now) {
    const nextState = {
      count: 1,
      resetAt: now + windowMs
    };
    rateLimitStore.set(key, nextState);
    return {
      allowed: true,
      limit,
      remaining: Math.max(0, limit - 1),
      resetAt: nextState.resetAt,
      retryAfter: 0
    };
  }

  if (current.count >= limit) {
    return {
      allowed: false,
      limit,
      remaining: 0,
      resetAt: current.resetAt,
      retryAfter: Math.max(1, Math.ceil((current.resetAt - now) / 1000))
    };
  }

  current.count += 1;
  rateLimitStore.set(key, current);

  return {
    allowed: true,
    limit,
    remaining: Math.max(0, limit - current.count),
    resetAt: current.resetAt,
    retryAfter: 0
  };
}

export function enforceCooldown(key: string, cooldownMs: number) {
  const now = getNow();
  const activeUntil = cooldownStore.get(key) ?? 0;

  if (activeUntil > now) {
    return {
      allowed: false,
      retryAfter: Math.max(1, Math.ceil((activeUntil - now) / 1000))
    };
  }

  cooldownStore.set(key, now + cooldownMs);
  return {
    allowed: true,
    retryAfter: 0
  };
}

export function applyRateLimitHeaders(response: NextResponse, result: RateLimitResult) {
  response.headers.set("X-RateLimit-Limit", String(result.limit));
  response.headers.set("X-RateLimit-Remaining", String(result.remaining));
  response.headers.set("X-RateLimit-Reset", String(Math.ceil(result.resetAt / 1000)));
  if (!result.allowed) {
    response.headers.set("Retry-After", String(result.retryAfter));
  }
  return response;
}

export function jsonError(message: string, status: number, rate?: RateLimitResult) {
  const response = NextResponse.json({ message }, { status });
  if (rate) {
    applyRateLimitHeaders(response, rate);
  }
  return response;
}

export async function isMaintenanceMode() {
  const setting = await prisma.systemSetting.findUnique({
    where: { key: "maintenance_mode" }
  });

  return setting?.value === "true";
}

export function assertApiKeyShape(apiKey: string | null) {
  if (!apiKey) {
    throw new Error("Missing API key.");
  }

  if (!apiKey.startsWith("ldb_") || apiKey.length < 20) {
    throw new Error("Invalid API key format.");
  }

  return apiKey.trim();
}

export function normalizeFilePath(path: string) {
  const normalized = `/${path.replace(/\\/g, "/").replace(/^\/+/, "")}`.replace(/\/+/g, "/");

  if (normalized.includes("..")) {
    throw new Error("Path traversal is not allowed.");
  }

  if (normalized.length > 180) {
    throw new Error("Path is too long.");
  }

  return normalized;
}

export function validateCollectionName(value: string) {
  const trimmed = value.trim();
  if (!/^[a-zA-Z0-9_-]{2,48}$/.test(trimmed)) {
    throw new Error("Collection name must be 2-48 chars and use only letters, numbers, dash, or underscore.");
  }
  return trimmed;
}

export function assertJsonObject(value: unknown) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error("Document data must be a JSON object.");
  }

  return value as Prisma.JsonObject;
}

export function assertPayloadBytes(serialized: string, maxBytes: number, label: string) {
  const bytes = Buffer.byteLength(serialized, "utf8");
  if (bytes > maxBytes) {
    throw new Error(`${label} exceeds ${maxBytes} bytes.`);
  }
  return bytes;
}

export function getBlockedIps() {
  return (process.env.SECURITY_BLOCKED_IPS ?? "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

export function assertIpAllowed(ip: string) {
  if (getBlockedIps().includes(ip)) {
    throw new Error("IP address is blocked.");
  }
}

export function assertPublicDatabaseReady(database: DbInstance & { plan?: Plan | null }, maintenanceMode: boolean) {
  if (maintenanceMode) {
    throw new Error("Platform is in maintenance mode.");
  }

  if (database.status === DbStatus.SUSPENDED) {
    throw new Error("Database is suspended.");
  }

  if (database.status === DbStatus.STOPPED) {
    throw new Error("Database is stopped.");
  }

  if (database.status === DbStatus.FAILED) {
    throw new Error("Database is unavailable.");
  }

  if (database.status !== DbStatus.RUNNING) {
    throw new Error(`Database is currently ${database.status.toLowerCase()}.`);
  }
}

export function getDocumentLimitBytes() {
  return Number(process.env.MAX_DOCUMENT_BYTES ?? 64 * 1024);
}

export function getFileLimitBytes() {
  return Number(process.env.MAX_FILE_BYTES ?? 256 * 1024);
}

export function getBotCooldownMs() {
  return Number(process.env.BOT_COMMAND_COOLDOWN_MS ?? 3000);
}

export function getDashboardCooldownMs() {
  return Number(process.env.DASHBOARD_ACTION_COOLDOWN_MS ?? 6000);
}

export function getDeployCooldownMs() {
  return Number(process.env.DEPLOY_ACTION_COOLDOWN_MS ?? 15000);
}

export function getPublicApiWindowMs() {
  return 60_000;
}
