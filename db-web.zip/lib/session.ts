import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "./auth";
import { prisma } from "./prisma";

export async function getCurrentSession() {
  return getServerSession(authOptions);
}

export async function getCurrentUser() {
  const session = await getCurrentSession();
  if (!session?.user?.id) {
    return null;
  }

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    include: {
      plan: true
    }
  });

  if (!user) {
    return null;
  }

  return user;
}

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) {
    redirect("/login");
  }

  return user;
}

export async function getCurrentAdmin() {
  const user = await getCurrentUser();
  if (!user) {
    return null;
  }

  if (user.role !== "ADMIN" && user.role !== "OWNER") {
    return null;
  }

  return user;
}

export async function requireAdmin() {
  const user = await getCurrentAdmin();
  if (!user) {
    redirect("/dashboard");
  }

  return user;
}
